package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.api.AiRecommendation
import com.example.api.GeminiRecommendHelper
import com.example.database.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class MusicViewModel(application: Application) : AndroidViewModel(application) {

    private val db = MusicDatabase.getDatabase(application, viewModelScope)
    private val repository = MusicRepository(db.musicDao())

    // --- REPOSITORY FLOWS ---
    val allSongs = repository.allSongs.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val musicOnlySongs = repository.musicOnlySongs.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val trendingSongs = repository.trendingSongs.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val newReleases = repository.newReleases.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val podcasts = repository.podcasts.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val radioStations = repository.radioStations.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val playlists = repository.playlists.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val favoriteSongs = repository.favoriteSongs.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val recentlyPlayed = repository.recentlyPlayed.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val downloadedSongs = repository.downloadedSongs.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // --- AUTHENTICATION STATE ---
    private val _isLoggedIn = MutableStateFlow(true) // Start logged in for seamless trial, can logout in settings
    val isLoggedIn: StateFlow<Boolean> = _isLoggedIn.asStateFlow()

    private val _userEmail = MutableStateFlow("anujkashyap1282@gmail.com")
    val userEmail: StateFlow<String> = _userEmail.asStateFlow()

    private val _username = MutableStateFlow("Anuj Kashyap")
    val username: StateFlow<String> = _username.asStateFlow()

    private val _isPremium = MutableStateFlow(false)
    val isPremium: StateFlow<Boolean> = _isPremium.asStateFlow()

    // --- PLAYBACK ENGINE STATE ---
    private val _currentPlayingSong = MutableStateFlow<SongEntity?>(null)
    val currentPlayingSong: StateFlow<SongEntity?> = _currentPlayingSong.asStateFlow()

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _currentProgress = MutableStateFlow(0L) // in seconds
    val currentProgress: StateFlow<Long> = _currentProgress.asStateFlow()

    private val _isShuffle = MutableStateFlow(false)
    val isShuffle: StateFlow<Boolean> = _isShuffle.asStateFlow()

    private val _isRepeat = MutableStateFlow(false)
    val isRepeat: StateFlow<Boolean> = _isRepeat.asStateFlow()

    private val _playbackSpeed = MutableStateFlow(1.0f)
    val playbackSpeed: StateFlow<Float> = _playbackSpeed.asStateFlow()

    private val _equalizerBass = MutableStateFlow(0.5f)
    val equalizerBass: StateFlow<Float> = _equalizerBass.asStateFlow()

    private val _equalizerMid = MutableStateFlow(0.6f)
    val equalizerMid: StateFlow<Float> = _equalizerMid.asStateFlow()

    private val _equalizerTreble = MutableStateFlow(0.5f)
    val equalizerTreble: StateFlow<Float> = _equalizerTreble.asStateFlow()

    private val _sleepTimerMinutes = MutableStateFlow(0) // 0 = off
    val sleepTimerMinutes: StateFlow<Int> = _sleepTimerMinutes.asStateFlow()

    private val _sleepTimerSecondsLeft = MutableStateFlow(0)
    val sleepTimerSecondsLeft: StateFlow<Int> = _sleepTimerSecondsLeft.asStateFlow()

    private val _playbackQueue = MutableStateFlow<List<SongEntity>>(emptyList())
    val playbackQueue: StateFlow<List<SongEntity>> = _playbackQueue.asStateFlow()

    private val _currentQueueIndex = MutableStateFlow(-1)
    val currentQueueIndex: StateFlow<Int> = _currentQueueIndex.asStateFlow()

    // --- AI RECOMMENDATION STATE ---
    private val _aiRecommendations = MutableStateFlow<List<AiRecommendation>>(emptyList())
    val aiRecommendations: StateFlow<List<AiRecommendation>> = _aiRecommendations.asStateFlow()

    private val _isAiLoading = MutableStateFlow(false)
    val isAiLoading: StateFlow<Boolean> = _isAiLoading.asStateFlow()

    private val _aiError = MutableStateFlow<String?>(null)
    val aiError: StateFlow<String?> = _aiError.asStateFlow()

    // --- APP SETTINGS STATE ---
    private val _language = MutableStateFlow("English") // English, Hindi
    val language: StateFlow<String> = _language.asStateFlow()

    private val _audioQuality = MutableStateFlow("High (320 kbps)") // Medium, High, Lossless
    val audioQuality: StateFlow<String> = _audioQuality.asStateFlow()

    private val _downloadQuality = MutableStateFlow("High (320 kbps)")
    val downloadQuality: StateFlow<String> = _downloadQuality.asStateFlow()

    private val _isDarkTheme = MutableStateFlow(true)
    val isDarkTheme: StateFlow<Boolean> = _isDarkTheme.asStateFlow()

    // Background jobs
    private var progressJob: Job? = null
    private var sleepTimerJob: Job? = null

    init {
        // Start simulated playback ticker
        startPlaybackTicker()
    }

    // --- AUTH ACTIONS ---
    fun login(email: String, name: String) {
        _userEmail.value = email
        _username.value = name
        _isLoggedIn.value = true
    }

    fun logout() {
        _isLoggedIn.value = false
        _isPlaying.value = false
        _currentPlayingSong.value = null
    }

    fun setPremiumStatus(isPrem: Boolean) {
        _isPremium.value = isPrem
    }

    // --- PLAYBACK ACTIONS ---
    fun selectSongAndPlay(song: SongEntity, currentList: List<SongEntity> = emptyList()) {
        val listToUse = currentList.ifEmpty { allSongs.value }
        _playbackQueue.value = listToUse
        val index = listToUse.indexOfFirst { it.id == song.id }
        _currentQueueIndex.value = if (index >= 0) index else 0
        
        _currentPlayingSong.value = song
        _currentProgress.value = 0L
        _isPlaying.value = true

        viewModelScope.launch(Dispatchers.IO) {
            repository.addToRecentlyPlayed(song.id)
        }
    }

    fun togglePlayPause() {
        if (_currentPlayingSong.value == null && allSongs.value.isNotEmpty()) {
            // Play first song if none selected
            selectSongAndPlay(allSongs.value.first())
        } else {
            _isPlaying.value = !_isPlaying.value
        }
    }

    fun nextSong() {
        val queueList = _playbackQueue.value
        if (queueList.isEmpty()) return

        var nextIndex = _currentQueueIndex.value + 1
        if (_isShuffle.value) {
            nextIndex = (queueList.indices).random()
        } else if (nextIndex >= queueList.size) {
            nextIndex = 0 // loop back
        }

        _currentQueueIndex.value = nextIndex
        val nextSong = queueList[nextIndex]
        _currentPlayingSong.value = nextSong
        _currentProgress.value = 0L
        _isPlaying.value = true

        viewModelScope.launch(Dispatchers.IO) {
            repository.addToRecentlyPlayed(nextSong.id)
        }
    }

    fun previousSong() {
        val queueList = _playbackQueue.value
        if (queueList.isEmpty()) return

        var prevIndex = _currentQueueIndex.value - 1
        if (prevIndex < 0) {
            prevIndex = queueList.size - 1 // wrap to end
        }

        _currentQueueIndex.value = prevIndex
        val prevSong = queueList[prevIndex]
        _currentPlayingSong.value = prevSong
        _currentProgress.value = 0L
        _isPlaying.value = true

        viewModelScope.launch(Dispatchers.IO) {
            repository.addToRecentlyPlayed(prevSong.id)
        }
    }

    fun seekTo(seconds: Long) {
        val song = _currentPlayingSong.value ?: return
        val maxDuration = if (song.duration == 0L) 300L else song.duration // Live radio stations act as live
        _currentProgress.value = seconds.coerceIn(0L, maxDuration)
    }

    fun toggleShuffle() {
        _isShuffle.value = !_isShuffle.value
    }

    fun toggleRepeat() {
        _isRepeat.value = !_isRepeat.value
    }

    fun setPlaybackSpeed(speed: Float) {
        _playbackSpeed.value = speed
    }

    // --- TIMER-BASED TICKER ---
    private fun startPlaybackTicker() {
        progressJob?.cancel()
        progressJob = viewModelScope.launch {
            while (true) {
                delay(1000)
                if (_isPlaying.value && _currentPlayingSong.value != null) {
                    val song = _currentPlayingSong.value!!
                    // For live radio stations, progress is visual loop
                    val duration = if (song.duration == 0L) 300L else song.duration
                    val nextProgress = _currentProgress.value + 1
                    
                    if (nextProgress >= duration) {
                        if (_isRepeat.value) {
                            _currentProgress.value = 0L
                        } else {
                            nextSong()
                        }
                    } else {
                        _currentProgress.value = nextProgress
                    }
                }
            }
        }
    }

    // --- SLEEP TIMER ---
    fun setSleepTimer(minutes: Int) {
        _sleepTimerMinutes.value = minutes
        _sleepTimerSecondsLeft.value = minutes * 60
        
        sleepTimerJob?.cancel()
        if (minutes > 0) {
            sleepTimerJob = viewModelScope.launch {
                while (_sleepTimerSecondsLeft.value > 0) {
                    delay(1000)
                    _sleepTimerSecondsLeft.value -= 1
                }
                // When timer hits 0, stop music!
                _isPlaying.value = false
                _sleepTimerMinutes.value = 0
            }
        }
    }

    // --- EQUALIZER ---
    fun updateEqualizer(bass: Float, mid: Float, treble: Float) {
        _equalizerBass.value = bass
        _equalizerMid.value = mid
        _equalizerTreble.value = treble
    }

    // --- DATABASE ACTIONS (LIKES, PLAYLISTS, DOWNLOADS) ---
    fun toggleFavorite(songId: Int, isFav: Boolean) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.toggleFavorite(songId, isFav)
        }
    }

    fun toggleDownload(songId: Int, isDownloaded: Boolean) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.toggleDownload(songId, isDownloaded)
        }
    }

    fun isSongFavorite(songId: Int): Flow<Boolean> = repository.isSongFavorite(songId)
    fun isSongDownloaded(songId: Int): Flow<Boolean> = repository.isSongDownloaded(songId)

    fun createPlaylist(name: String) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.insertPlaylist(name)
        }
    }

    fun deletePlaylist(playlistId: Int) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.deletePlaylist(playlistId)
        }
    }

    fun addSongToPlaylist(playlistId: Int, songId: Int) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.addSongToPlaylist(playlistId, songId)
        }
    }

    fun removeSongFromPlaylist(playlistId: Int, songId: Int) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.removeSongFromPlaylist(playlistId, songId)
        }
    }

    fun getSongsInPlaylist(playlistId: Int) = repository.getSongsInPlaylist(playlistId)

    // --- ADMIN PANEL ACTIONS ---
    fun addCustomSong(
        title: String,
        artist: String,
        album: String,
        category: String,
        duration: Long,
        lyrics: String,
        isTrending: Boolean,
        isNewRelease: Boolean,
        isPodcast: Boolean,
        isRadio: Boolean
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            val imageSeed = category.lowercase().trim() + "_" + title.lowercase().trim().take(3)
            val newSong = SongEntity(
                title = title,
                artist = artist,
                album = album,
                category = category,
                duration = duration,
                imageUrl = imageSeed,
                lyrics = lyrics.ifEmpty { "[00:01] (Instrumental Uplifting $category Beats)" },
                isTrending = isTrending,
                isNewRelease = isNewRelease,
                isPodcast = isPodcast,
                isRadio = isRadio
            )
            repository.insertSong(newSong)
        }
    }

    fun deleteSong(songId: Int) {
        viewModelScope.launch(Dispatchers.IO) {
            if (_currentPlayingSong.value?.id == songId) {
                _isPlaying.value = false
                _currentPlayingSong.value = null
            }
            repository.deleteSongById(songId)
        }
    }

    // --- AI MUSIC RECOMMENDATIONS ---
    fun fetchAiRecommendations(mood: String) {
        _isAiLoading.value = true
        _aiError.value = null
        viewModelScope.launch {
            try {
                val favGenres = allSongs.value.take(3).map { it.category }.distinct().joinToString(", ")
                val recs = GeminiRecommendHelper.getAiRecommendations(mood, favGenres)
                _aiRecommendations.value = recs
            } catch (e: Exception) {
                _aiError.value = e.message ?: "Failed to get AI suggestions"
            } finally {
                _isAiLoading.value = false
            }
        }
    }

    // --- SETTINGS CONTROLS ---
    fun setLanguage(lang: String) {
        _language.value = lang
    }

    fun setAudioQuality(quality: String) {
        _audioQuality.value = quality
    }

    fun setDownloadQuality(quality: String) {
        _downloadQuality.value = quality
    }

    fun setDarkTheme(dark: Boolean) {
        _isDarkTheme.value = dark
    }

    fun clearRecentlyPlayed() {
        viewModelScope.launch(Dispatchers.IO) {
            repository.clearHistory()
        }
    }
}
