package com.example.api

import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import kotlinx.serialization.json.putJsonObject
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.ResponseBody
import retrofit2.Retrofit
import retrofit2.converter.kotlinx.serialization.asConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.http.Query
import java.util.concurrent.TimeUnit

@Serializable
data class GenerateContentRequest(
    val contents: List<Content>,
    val generationConfig: GenerationConfig? = null,
    val systemInstruction: Content? = null
)

@Serializable
data class Content(
    val parts: List<Part>
)

@Serializable
data class Part(
    val text: String
)

@Serializable
data class GenerationConfig(
    val responseFormat: ResponseFormat? = null,
    val temperature: Float? = null
)

@Serializable
data class ResponseFormat(
    val type: String, // "application/json"
    val responseSchema: JsonObject? = null
)

@Serializable
data class GenerateContentResponse(
    val candidates: List<Candidate>
)

@Serializable
data class Candidate(
    val content: Content
)

interface GeminiApiService {
    @POST("v1beta/models/gemini-3.5-flash:generateContent")
    suspend fun generateContent(
        @Query("key") apiKey: String,
        @Body request: GenerateContentRequest
    ): GenerateContentResponse
}

object RetrofitClient {
    private const val BASE_URL = "https://generativelanguage.googleapis.com/"

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    val service: GeminiApiService by lazy {
        val json = Json { ignoreUnknownKeys = true }
        val retrofit = Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(json.asConverterFactory("application/json".toMediaType()))
            .build()
        retrofit.create(GeminiApiService::class.java)
    }
}

@Serializable
data class AiRecommendation(
    val title: String,
    val artist: String,
    val genre: String,
    val reason: String
)

object GeminiRecommendHelper {

    suspend fun getAiRecommendations(mood: String, favoriteGenres: String): List<AiRecommendation> = withContext(Dispatchers.IO) {
        val apiKey = BuildConfig.GEMINI_API_KEY
        if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
            // Return high-quality offline fallbacks if the key isn't provided
            return@withContext getLocalRecommendations(mood)
        }

        val prompt = """
            Recommend 4 beautiful, real-world songs for someone feeling '$mood'.
            Their favorite music genres are: $favoriteGenres.
            Provide your response STRICTLY as a raw JSON array matching this format:
            [
              {
                "title": "Song Name",
                "artist": "Artist Name",
                "genre": "Pop",
                "reason": "Why this song is perfect for this mood"
              }
            ]
            Do not wrap your response in markdown code blocks like ```json. Return ONLY the raw JSON string.
        """.trimIndent()

        // Configure generationConfig to request application/json output type
        val request = GenerateContentRequest(
            contents = listOf(Content(parts = listOf(Part(text = prompt)))),
            generationConfig = GenerationConfig(
                responseFormat = ResponseFormat(type = "application/json"),
                temperature = 0.7f
            ),
            systemInstruction = Content(parts = listOf(Part(text = "You are a professional music recommendations AI. You suggest amazing, highly relevant music.")))
        )

        try {
            val response = RetrofitClient.service.generateContent(apiKey, request)
            val jsonString = response.candidates.firstOrNull()?.content?.parts?.firstOrNull()?.text
                ?: return@withContext getLocalRecommendations(mood)
            
            val jsonParser = Json { ignoreUnknownKeys = true }
            jsonParser.decodeFromString<List<AiRecommendation>>(jsonString)
        } catch (e: Exception) {
            e.printStackTrace()
            getLocalRecommendations(mood)
        }
    }

    private fun getLocalRecommendations(mood: String): List<AiRecommendation> {
        val cleanMood = mood.lowercase()
        return when {
            cleanMood.contains("happy") || cleanMood.contains("energetic") || cleanMood.contains("dance") -> listOf(
                AiRecommendation("Can't Stop the Feeling!", "Justin Timberlake", "Pop", "Infectious energetic dance pop to boost your mood!"),
                AiRecommendation("Uptown Funk", "Mark Ronson ft. Bruno Mars", "Funk", "Unmatched high-energy groove to get you dancing."),
                AiRecommendation("Happy", "Pharrell Williams", "Pop", "The classic anthem of pure joy and positivity!"),
                AiRecommendation("Don't Stop Me Now", "Queen", "Rock", "An unstoppable, high-speed rock rush!")
            )
            cleanMood.contains("sad") || cleanMood.contains("melancholy") || cleanMood.contains("cry") -> listOf(
                AiRecommendation("Someone Like You", "Adele", "Pop", "A deeply moving piano ballad about lost love."),
                AiRecommendation("Fix You", "Coldplay", "Rock", "A comforting build-up that brings solace to heavy hearts."),
                AiRecommendation("Yesterday", "The Beatles", "Pop", "A beautiful acoustic reflection on sorrow and looking back."),
                AiRecommendation("Stay With Me", "Sam Smith", "Pop", "A soulful, gospel-backed cry for emotional presence.")
            )
            cleanMood.contains("relax") || cleanMood.contains("chill") || cleanMood.contains("sleep") -> listOf(
                AiRecommendation("Weightless", "Marconi Union", "Ambient", "Scientifically proven to reduce stress and assist relaxation."),
                AiRecommendation("Strawberry Swing", "Coldplay", "Alternative", "Lush soundscapes and warm acoustic guitars to wind down."),
                AiRecommendation("Gymnopédie No. 1", "Erik Satie", "Classical", "An exceptionally peaceful, floating solo piano piece."),
                AiRecommendation("Sunrise", "Norah Jones", "Jazz", "Soft vocal lines and soothing acoustic piano vibes.")
            )
            else -> listOf(
                AiRecommendation("Stayin' Alive", "Bee Gees", "Disco", "A classic groovy hit that works for any time of day."),
                AiRecommendation("Bohemian Rhapsody", "Queen", "Rock", "A multi-layered operatic rock masterpiece for curious ears."),
                AiRecommendation("Lose Yourself", "Eminem", "Hip-Hop", "A timeless anthem of drive and intense motivation."),
                AiRecommendation("Clair de Lune", "Claude Debussy", "Classical", "An impressionistic piano piece to clear and calm your mind.")
            )
        }
    }
}
