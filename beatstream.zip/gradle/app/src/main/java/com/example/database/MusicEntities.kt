package com.example.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "songs")
data class SongEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val artist: String,
    val album: String,
    val category: String, // Pop, Rock, Hip-Hop, Classical, Electronic, etc.
    val duration: Long, // in seconds
    val imageUrl: String, // Resource name or URL
    val lyrics: String, // Synced or scrolling lyrics
    val isTrending: Boolean = false,
    val isNewRelease: Boolean = false,
    val isPodcast: Boolean = false,
    val isRadio: Boolean = false
)

@Entity(tableName = "playlists")
data class PlaylistEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "playlist_songs", primaryKeys = ["playlistId", "songId"])
data class PlaylistSongEntity(
    val playlistId: Int,
    val songId: Int
)

@Entity(tableName = "favorites")
data class FavoriteEntity(
    @PrimaryKey val songId: Int,
    val likedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "history")
data class HistoryEntity(
    @PrimaryKey val songId: Int,
    val playedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "downloads")
data class DownloadEntity(
    @PrimaryKey val songId: Int,
    val downloadedAt: Long = System.currentTimeMillis()
)
