package com.example.ui

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.api.AiRecommendation
import com.example.database.PlaylistEntity
import com.example.database.SongEntity
import com.example.ui.theme.*
import com.example.viewmodel.MusicViewModel
import kotlinx.coroutines.launch

// Navigation tabs
enum class MusicTab(val icon: ImageVector, val label: String, val labelHi: String) {
    HOME(Icons.Default.Home, "Home", "होम"),
    SEARCH(Icons.Default.Search, "Search", "खोजें"),
    LIBRARY(Icons.Default.LibraryMusic, "Library", "लाइब्रेरी"),
    PREMIUM(Icons.Default.WorkspacePremium, "Premium", "प्रीमियम"),
    PROFILE(Icons.Default.Person, "Profile", "प्रोफ़ाइल")
}

@Composable
fun MusicAppContent(viewModel: MusicViewModel) {
    val isLoggedIn by viewModel.isLoggedIn.collectAsStateWithLifecycle()
    val isDarkTheme by viewModel.isDarkTheme.collectAsStateWithLifecycle()

    MyApplicationTheme(darkTheme = isDarkTheme) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = MaterialTheme.colorScheme.background
        ) {
            if (!isLoggedIn) {
                LoginScreen(viewModel)
            } else {
                MainAppLayout(viewModel)
            }
        }
    }
}

// --- HELPER ALBUM ART DESIGN ---
@Composable
fun AlbumArtComponent(
    seed: String,
    modifier: Modifier = Modifier,
    isRounded: Boolean = false,
    iconSize: Int = 32
) {
    val hash = seed.hashCode()
    val brush = remember(seed) {
        val baseColor = when {
            seed.contains("pop", ignoreCase = true) -> CosmicPurple
            seed.contains("rock", ignoreCase = true) -> Color(0xFFE63946)
            seed.contains("hiphop", ignoreCase = true) -> CosmicCyan
            seed.contains("classical", ignoreCase = true) -> Color(0xFFFFB703)
            seed.contains("electronic", ignoreCase = true) -> CyberPink
            seed.contains("jazz", ignoreCase = true) -> Color(0xFF1D3557)
            seed.contains("podcast", ignoreCase = true) -> Color(0xFF8338EC)
            seed.contains("radio", ignoreCase = true) -> Color(0xFFFB5607)
            else -> {
                val colorsList = listOf(CosmicPurple, CosmicCyan, CyberPink, Color(0xFF8338EC), Color(0xFFFB5607), Color(0xFFFFB703))
                colorsList[Math.abs(hash) % colorsList.size]
            }
        }
        val gradientEnd = when {
            seed.contains("pop", ignoreCase = true) -> CyberPink
            seed.contains("rock", ignoreCase = true) -> Color.Black
            seed.contains("hiphop", ignoreCase = true) -> Color(0xFF1E1F2C)
            seed.contains("classical", ignoreCase = true) -> Color(0xFF4A154B)
            seed.contains("electronic", ignoreCase = true) -> Color(0xFF00F5D4)
            seed.contains("jazz", ignoreCase = true) -> Color(0xFF457B9D)
            seed.contains("podcast", ignoreCase = true) -> Color(0xFFFF006E)
            seed.contains("radio", ignoreCase = true) -> Color(0xFFFFBE0B)
            else -> {
                val endColorsList = listOf(Color.Black, Color(0xFF1E1F2C), Color(0xFF4A154B), Color(0xFF00F5D4))
                endColorsList[Math.abs(hash * 31) % endColorsList.size]
            }
        }
        Brush.linearGradient(listOf(baseColor, gradientEnd))
    }

    Box(
        modifier = modifier
            .clip(if (isRounded) CircleShape else RoundedCornerShape(12.dp))
            .background(brush),
        contentAlignment = Alignment.Center
    ) {
        // Overlay sound waves pattern inside the art box
        Canvas(modifier = Modifier.fillMaxSize().scale(0.85f)) {
            val waveWidth = size.width / 5
            val centerY = size.height / 2
            val randomOffset = Math.abs(hash) % 10 + 5
            for (i in 0 until 4) {
                val heightPercent = listOf(0.4f, 0.7f, 0.5f, 0.8f)[(i + randomOffset) % 4]
                drawRoundRect(
                    color = Color.White.copy(alpha = 0.2f),
                    topLeft = androidx.compose.ui.geometry.Offset(
                        x = waveWidth / 2 + i * waveWidth * 1.2f,
                        y = centerY - (size.height * heightPercent) / 2
                    ),
                    size = androidx.compose.ui.geometry.Size(
                        width = waveWidth * 0.5f,
                        height = size.height * heightPercent
                    ),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(10f, 10f)
                )
            }
        }

        // Beautiful centered music element
        Icon(
            imageVector = when {
                seed.contains("podcast", ignoreCase = true) -> Icons.Default.Podcasts
                seed.contains("radio", ignoreCase = true) -> Icons.Default.Radio
                else -> Icons.Default.MusicNote
            },
            contentDescription = "Cover Art Detail",
            tint = Color.White,
            modifier = Modifier.size(iconSize.dp)
        )
    }
}

// --- AUTHENTICATION SCREEN ---
@Composable
fun LoginScreen(viewModel: MusicViewModel) {
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var isPhoneLogin by remember { mutableStateOf(false) }

    val context = LocalContext.current

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(SpaceBlack, DarkSlateSurface)
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(28.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // App Logo Illustration
            AlbumArtComponent(
                seed = "podcast_welcome",
                modifier = Modifier
                    .size(100.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .padding(8.dp),
                iconSize = 48
            )

            Text(
                text = "BeatStream",
                fontSize = 32.sp,
                fontWeight = FontWeight.Bold,
                color = CosmicPurple,
                textAlign = TextAlign.Center
            )

            Text(
                text = "Immersive Audio Experience awaits you",
                fontSize = 14.sp,
                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f),
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Login toggles
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(DarkSlateCard, RoundedCornerShape(12.dp))
                    .padding(4.dp),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                Button(
                    onClick = { isPhoneLogin = false },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (!isPhoneLogin) CosmicPurple else Color.Transparent,
                        contentColor = if (!isPhoneLogin) Color.Black else Color.White
                    ),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Email")
                }
                Button(
                    onClick = { isPhoneLogin = true },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isPhoneLogin) CosmicPurple else Color.Transparent,
                        contentColor = if (isPhoneLogin) Color.Black else Color.White
                    ),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Phone")
                }
            }

            if (!isPhoneLogin) {
                // Email Auth
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Display Name") },
                    leadingIcon = { Icon(Icons.Default.Person, contentDescription = null) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("login_name_input"),
                    shape = RoundedCornerShape(12.dp)
                )

                OutlinedTextField(
                    value = email,
                    onValueChange = { email = it },
                    label = { Text("Email Address") },
                    leadingIcon = { Icon(Icons.Default.Email, contentDescription = null) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("login_email_input"),
                    shape = RoundedCornerShape(12.dp)
                )

                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it },
                    label = { Text("Password") },
                    leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("login_password_input"),
                    shape = RoundedCornerShape(12.dp)
                )
            } else {
                // Phone Auth
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Display Name") },
                    leadingIcon = { Icon(Icons.Default.Person, contentDescription = null) },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                )

                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text("Phone Number") },
                    leadingIcon = { Icon(Icons.Default.Phone, contentDescription = null) },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                )
            }

            Button(
                onClick = {
                    val cleanName = name.ifEmpty { "BeatStream Guest" }
                    val cleanEmail = email.ifEmpty { if (isPhoneLogin) phone else "anujkashyap1282@gmail.com" }
                    viewModel.login(cleanEmail, cleanName)
                    Toast.makeText(context, "Welcome back, $cleanName!", Toast.LENGTH_SHORT).show()
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("login_submit_button"),
                colors = ButtonDefaults.buttonColors(containerColor = CosmicPurple, contentColor = Color.Black),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text(
                    text = if (isPhoneLogin) "Send OTP & Login" else "Login / Sign Up",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Text(
                text = "Or continue with",
                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f),
                fontSize = 12.sp
            )

            // Google sign-in simulation
            OutlinedButton(
                onClick = {
                    viewModel.login("anujkashyap1282@gmail.com", "Anuj Kashyap")
                    Toast.makeText(context, "Logged in via Google", Toast.LENGTH_SHORT).show()
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.PlayCircleFilled, // Abstract G sign
                        contentDescription = "Google Logo",
                        tint = CosmicCyan
                    )
                    Text("Continue with Google")
                }
            }
        }
    }
}

// --- MASTER LAYOUT ---
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainAppLayout(viewModel: MusicViewModel) {
    var selectedTab by remember { mutableStateOf(MusicTab.HOME) }
    val currentSong by viewModel.currentPlayingSong.collectAsStateWithLifecycle()
    val isPlaying by viewModel.isPlaying.collectAsStateWithLifecycle()
    val language by viewModel.language.collectAsStateWithLifecycle()

    var showFullPlayer by remember { mutableStateOf(false) }

    Scaffold(
        bottomBar = {
            Column {
                // MINI PLAYER
                if (currentSong != null) {
                    MiniPlayerBar(
                        song = currentSong!!,
                        isPlaying = isPlaying,
                        viewModel = viewModel,
                        onBarClick = { showFullPlayer = true }
                    )
                }

                // BOTTOM NAVIGATION
                NavigationBar(
                    containerColor = DarkSlateSurface,
                    tonalElevation = 8.dp
                ) {
                    MusicTab.values().forEach { tab ->
                        val isSelected = selectedTab == tab
                        NavigationBarItem(
                            selected = isSelected,
                            onClick = { selectedTab = tab },
                            icon = {
                                Icon(
                                    imageVector = tab.icon,
                                    contentDescription = tab.label
                                )
                            },
                            label = {
                                Text(
                                    text = if (language == "Hindi") tab.labelHi else tab.label,
                                    fontSize = 11.sp
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Color.Black,
                                selectedTextColor = CosmicPurple,
                                indicatorColor = CosmicPurple,
                                unselectedIconColor = Color.White.copy(alpha = 0.6f),
                                unselectedTextColor = Color.White.copy(alpha = 0.6f)
                            )
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Main content based on active tab
            Crossfade(targetState = selectedTab, label = "TabTransition") { tab ->
                when (tab) {
                    MusicTab.HOME -> HomeScreen(viewModel)
                    MusicTab.SEARCH -> SearchScreen(viewModel)
                    MusicTab.LIBRARY -> LibraryScreen(viewModel)
                    MusicTab.PREMIUM -> PremiumScreen(viewModel)
                    MusicTab.PROFILE -> ProfileScreen(viewModel)
                }
            }

            // FULL SCREEN PLAYER OVERLAY SHEET
            AnimatedVisibility(
                visible = showFullPlayer,
                enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
                exit = slideOutVertically(targetOffsetY = { it }) + fadeOut()
            ) {
                if (currentSong != null) {
                    FullPlayerScreen(
                        song = currentSong!!,
                        viewModel = viewModel,
                        onDismiss = { showFullPlayer = false }
                    )
                }
            }
        }
    }
}

// --- MINI PLAYER BAR ---
@Composable
fun MiniPlayerBar(
    song: SongEntity,
    isPlaying: Boolean,
    viewModel: MusicViewModel,
    onBarClick: () -> Unit
) {
    val isFav by viewModel.isSongFavorite(song.id).collectAsStateWithLifecycle(initialValue = false)
    val progress by viewModel.currentProgress.collectAsStateWithLifecycle()
    val totalDuration = if (song.duration == 0L) 300L else song.duration
    val progressFraction = progress.toFloat() / totalDuration.toFloat()

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(DarkSlateCard)
            .clickable(onClick = onBarClick)
    ) {
        // Linear Progress bar
        LinearProgressIndicator(
            progress = progressFraction.coerceIn(0f, 1f),
            modifier = Modifier.fillMaxWidth().height(2.dp),
            color = CosmicCyan,
            trackColor = Color.White.copy(alpha = 0.15f)
        )

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                AlbumArtComponent(
                    seed = song.imageUrl,
                    modifier = Modifier.size(44.dp)
                )

                Spacer(modifier = Modifier.width(12.dp))

                Column {
                    Text(
                        text = song.title,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = Color.White,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = song.artist,
                        fontSize = 12.sp,
                        color = Color.White.copy(alpha = 0.6f),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                IconButton(
                    onClick = { viewModel.toggleFavorite(song.id, isFav) }
                ) {
                    Icon(
                        imageVector = if (isFav) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                        contentDescription = "Favorite",
                        tint = if (isFav) CyberPink else Color.White
                    )
                }

                IconButton(
                    onClick = { viewModel.togglePlayPause() }
                ) {
                    Icon(
                        imageVector = if (isPlaying) Icons.Default.PauseCircle else Icons.Default.PlayCircle,
                        contentDescription = "Play/Pause",
                        tint = CosmicPurple,
                        modifier = Modifier.size(34.dp)
                    )
                }

                IconButton(
                    onClick = { viewModel.nextSong() }
                ) {
                    Icon(
                        imageVector = Icons.Default.SkipNext,
                        contentDescription = "Next Track",
                        tint = Color.White
                    )
                }
            }
        }
    }
}

// --- HOME SCREEN ---
@Composable
fun HomeScreen(viewModel: MusicViewModel) {
    val trending by viewModel.trendingSongs.collectAsStateWithLifecycle()
    val newReleases by viewModel.newReleases.collectAsStateWithLifecycle()
    val recentlyPlayed by viewModel.recentlyPlayed.collectAsStateWithLifecycle()
    val podcasts by viewModel.podcasts.collectAsStateWithLifecycle()
    val radioStations by viewModel.radioStations.collectAsStateWithLifecycle()
    val language by viewModel.language.collectAsStateWithLifecycle()
    val sleepMinutesLeft by viewModel.sleepTimerSecondsLeft.collectAsStateWithLifecycle()

    var activeCategoryTab by remember { mutableStateOf("All") } // All, Podcasts, Live Radio

    val sampleBanners = listOf(
        Pair("Global Hits Live", "Listen to today's trending billboard tracks"),
        Pair("Chill Acoustic Sessions", "Relaxing tracks to calm your thoughts"),
        Pair("Lofi Coding Loops", "High focus programming beat sessions")
    )

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(SpaceBlack)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        // --- TOP BAR ---
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = if (language == "Hindi") "नमस्ते," else "Good Day,",
                        fontSize = 14.sp,
                        color = Color.White.copy(alpha = 0.5f)
                    )
                    Text(
                        text = "BeatStream Music",
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold,
                        color = CosmicPurple
                    )
                }

                // Active sleep timer badge
                if (sleepMinutesLeft > 0) {
                    AssistChip(
                        onClick = { viewModel.setSleepTimer(0) },
                        label = { Text("Timer: ${sleepMinutesLeft / 60}m") },
                        leadingIcon = { Icon(Icons.Default.AlarmOn, contentDescription = null, tint = CosmicCyan) },
                        colors = AssistChipDefaults.assistChipColors(containerColor = DarkSlateCard)
                    )
                }
            }
        }

        // --- MEDIA CATEGORY TOGGLES ---
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf("All", "Podcasts", "Live Radio").forEach { tab ->
                    FilterChip(
                        selected = activeCategoryTab == tab,
                        onClick = { activeCategoryTab = tab },
                        label = { Text(tab) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = CosmicPurple,
                            selectedLabelColor = Color.Black,
                            containerColor = DarkSlateCard,
                            labelColor = Color.White
                        )
                    )
                }
            }
        }

        if (activeCategoryTab == "All") {
            // --- HERO BANNER CAROUSEL ---
            item {
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(sampleBanners) { banner ->
                        Box(
                            modifier = Modifier
                                .width(280.dp)
                                .height(140.dp)
                                .clip(RoundedCornerShape(16.dp))
                                .background(
                                    Brush.horizontalGradient(
                                        listOf(DarkSlateCard, Color(0xFF2C1B4D))
                                    )
                                )
                                .border(1.dp, CosmicPurple.copy(alpha = 0.3f), RoundedCornerShape(16.dp))
                                .padding(16.dp)
                        ) {
                            Column(
                                modifier = Modifier.fillMaxHeight(),
                                verticalArrangement = Arrangement.SpaceBetween
                            ) {
                                Badge(containerColor = CosmicCyan, contentColor = Color.Black) {
                                    Text("FEATURED", fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 4.dp))
                                }
                                Column {
                                    Text(banner.first, fontWeight = FontWeight.Bold, fontSize = 18.sp, color = Color.White)
                                    Text(banner.second, fontSize = 12.sp, color = Color.White.copy(alpha = 0.6f))
                                }
                            }
                        }
                    }
                }
            }

            // --- RECENTLY PLAYED ---
            if (recentlyPlayed.isNotEmpty()) {
                item {
                    Text(
                        text = if (language == "Hindi") "हाल ही में बजाया गया" else "Recently Played",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        items(recentlyPlayed) { song ->
                            Column(
                                modifier = Modifier
                                    .width(110.dp)
                                    .clickable { viewModel.selectSongAndPlay(song, recentlyPlayed) },
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                AlbumArtComponent(seed = song.imageUrl, modifier = Modifier.size(100.dp))
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(song.title, fontWeight = FontWeight.Bold, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, color = Color.White)
                                Text(song.artist, fontSize = 10.sp, color = Color.White.copy(alpha = 0.5f), maxLines = 1)
                            }
                        }
                    }
                }
            }

            // --- TRENDING HIT PLAYLISTS ---
            item {
                Text(
                    text = if (language == "Hindi") "ट्रेंडिंग गाने" else "Trending Hits",
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    color = Color.White
                )
                Spacer(modifier = Modifier.height(8.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(trending) { song ->
                        Card(
                            onClick = { viewModel.selectSongAndPlay(song, trending) },
                            modifier = Modifier.width(140.dp),
                            colors = CardDefaults.cardColors(containerColor = DarkSlateCard)
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                AlbumArtComponent(seed = song.imageUrl, modifier = Modifier.size(120.dp))
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(song.title, fontWeight = FontWeight.Bold, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, color = Color.White)
                                Text(song.artist, fontSize = 11.sp, color = Color.White.copy(alpha = 0.6f), maxLines = 1)
                            }
                        }
                    }
                }
            }

            // --- AI RECOMMENDATIONS PANEL ---
            item {
                AiRecommendationsSection(viewModel)
            }

            // --- NEW RELEASES ---
            item {
                Text(
                    text = if (language == "Hindi") "नई रिलीज़" else "New Releases",
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    color = Color.White
                )
                Spacer(modifier = Modifier.height(8.dp))
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    newReleases.forEach { song ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(DarkSlateCard, RoundedCornerShape(8.dp))
                                .clickable { viewModel.selectSongAndPlay(song, newReleases) }
                                .padding(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            AlbumArtComponent(seed = song.imageUrl, modifier = Modifier.size(50.dp))
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(song.title, fontWeight = FontWeight.Bold, color = Color.White, fontSize = 14.sp)
                                Text(song.artist, color = Color.White.copy(alpha = 0.6f), fontSize = 12.sp)
                            }
                            IconButton(onClick = { viewModel.selectSongAndPlay(song, newReleases) }) {
                                Icon(Icons.Default.PlayArrow, contentDescription = "Play", tint = CosmicCyan)
                            }
                        }
                    }
                }
            }

            // --- GENRES GRID ---
            item {
                Text(
                    text = if (language == "Hindi") "शैलियाँ" else "Featured Genres",
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    color = Color.White
                )
                Spacer(modifier = Modifier.height(8.dp))
                val genres = listOf("Pop", "Rock", "Hip-Hop", "Classical", "Electronic", "Jazz")
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    genres.forEach { genre ->
                        Box(
                            modifier = Modifier
                                .width(120.dp)
                                .height(70.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(
                                    Brush.linearGradient(
                                        listOf(
                                            when (genre) {
                                                "Pop" -> CosmicPurple
                                                "Rock" -> Color(0xFFD62246)
                                                "Hip-Hop" -> CosmicCyan
                                                "Classical" -> Color(0xFFC77DFF)
                                                "Electronic" -> CyberPink
                                                else -> Color(0xFF0077B6)
                                            }, Color.Black
                                        )
                                    )
                                )
                                .padding(12.dp),
                            contentAlignment = Alignment.BottomStart
                        ) {
                            Text(genre, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color.White)
                        }
                    }
                }
            }
        } else if (activeCategoryTab == "Podcasts") {
            // --- PODCASTS TAB ---
            item {
                Text("Popular Podcasts", fontWeight = FontWeight.Bold, fontSize = 20.sp, color = CosmicPurple)
                Spacer(modifier = Modifier.height(4.dp))
                Text("Insightful conversations, stories, and educational shows", fontSize = 12.sp, color = Color.White.copy(alpha = 0.5f))
            }

            if (podcasts.isEmpty()) {
                item {
                    Text("No podcasts available.", color = Color.White.copy(alpha = 0.5f))
                }
            } else {
                items(podcasts) { podcast ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(DarkSlateCard, RoundedCornerShape(12.dp))
                            .clickable { viewModel.selectSongAndPlay(podcast, podcasts) }
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        AlbumArtComponent(seed = podcast.imageUrl, modifier = Modifier.size(64.dp))
                        Spacer(modifier = Modifier.width(14.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(podcast.title, fontWeight = FontWeight.Bold, color = Color.White, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text("Host: ${podcast.artist}", color = CosmicCyan, fontSize = 12.sp)
                            Text("Show: ${podcast.album}", color = Color.White.copy(alpha = 0.6f), fontSize = 11.sp)
                        }
                        IconButton(onClick = { viewModel.selectSongAndPlay(podcast, podcasts) }) {
                            Icon(Icons.Default.PlayArrow, contentDescription = "Play", tint = CosmicPurple, modifier = Modifier.size(28.dp))
                        }
                    }
                }
            }
        } else {
            // --- LIVE RADIO TAB ---
            item {
                Text("FM & Digital Radio Stations", fontWeight = FontWeight.Bold, fontSize = 20.sp, color = CosmicCyan)
                Spacer(modifier = Modifier.height(4.dp))
                Text("Stream global live music broadcasts and news instantly", fontSize = 12.sp, color = Color.White.copy(alpha = 0.5f))
            }

            if (radioStations.isEmpty()) {
                item {
                    Text("No radio stations available.", color = Color.White.copy(alpha = 0.5f))
                }
            } else {
                items(radioStations) { radio ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(DarkSlateCard, RoundedCornerShape(12.dp))
                            .clickable { viewModel.selectSongAndPlay(radio, radioStations) }
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        AlbumArtComponent(seed = radio.imageUrl, modifier = Modifier.size(64.dp))
                        Spacer(modifier = Modifier.width(14.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(radio.title, fontWeight = FontWeight.Bold, color = Color.White, fontSize = 14.sp)
                            Text(radio.artist, color = CosmicPurple, fontSize = 12.sp)
                            Badge(containerColor = CyberPink, contentColor = Color.White) {
                                Text("LIVE TRANSMISSION", fontSize = 9.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 4.dp))
                            }
                        }
                        IconButton(onClick = { viewModel.selectSongAndPlay(radio, radioStations) }) {
                            Icon(Icons.Default.Radio, contentDescription = "Play", tint = CosmicCyan, modifier = Modifier.size(28.dp))
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(40.dp))
        }
    }
}

// --- AI RECOMMENDATIONS COMPONENT ---
@Composable
fun AiRecommendationsSection(viewModel: MusicViewModel) {
    var moodInput by remember { mutableStateOf("") }
    val recommendations by viewModel.aiRecommendations.collectAsStateWithLifecycle()
    val isLoading by viewModel.isAiLoading.collectAsStateWithLifecycle()
    val error by viewModel.aiError.collectAsStateWithLifecycle()

    val context = LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(DarkSlateCard, RoundedCornerShape(16.dp))
            .border(1.dp, CosmicCyan.copy(alpha = 0.2f), RoundedCornerShape(16.dp))
            .padding(14.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Icon(Icons.Default.AutoAwesome, contentDescription = "AI", tint = CosmicCyan)
            Text("AI Smart Mood Matcher", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color.White)
        }

        Text(
            text = "Enter how you are feeling, and our Gemini AI model will match songs to your current mood state.",
            fontSize = 11.sp,
            color = Color.White.copy(alpha = 0.6f),
            modifier = Modifier.padding(vertical = 4.dp)
        )

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = moodInput,
                onValueChange = { moodInput = it },
                placeholder = { Text("e.g. Chill rainy Sunday, energetic running, sad", fontSize = 12.sp) },
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(10.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = CosmicCyan,
                    unfocusedBorderColor = Color.White.copy(alpha = 0.2f)
                ),
                maxLines = 1
            )

            Button(
                onClick = {
                    if (moodInput.trim().isNotEmpty()) {
                        viewModel.fetchAiRecommendations(moodInput)
                    } else {
                        Toast.makeText(context, "Please enter a mood first!", Toast.LENGTH_SHORT).show()
                    }
                },
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(containerColor = CosmicCyan, contentColor = Color.Black)
            ) {
                if (isLoading) {
                    CircularProgressIndicator(modifier = Modifier.size(18.dp), color = Color.Black, strokeWidth = 2.dp)
                } else {
                    Text("Ask", fontWeight = FontWeight.Bold)
                }
            }
        }

        if (error != null) {
            Text("Error: $error", color = Color.Red, fontSize = 11.sp)
        }

        if (recommendations.isNotEmpty()) {
            Spacer(modifier = Modifier.height(8.dp))
            Text("Gemini Recommended Tracks:", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = CosmicCyan)
            Column(
                modifier = Modifier.padding(top = 4.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                recommendations.forEach { rec ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(SpaceBlack.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
                            .padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(rec.title, fontWeight = FontWeight.Bold, color = Color.White, fontSize = 12.sp)
                            Text("${rec.artist} • ${rec.genre}", color = CosmicPurple, fontSize = 11.sp)
                            Text(rec.reason, fontSize = 10.sp, color = Color.White.copy(alpha = 0.5f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }

                        IconButton(
                            onClick = {
                                // Add custom dynamic track if search doesn't find it
                                viewModel.addCustomSong(
                                    title = rec.title,
                                    artist = rec.artist,
                                    album = "Gemini Recommendations",
                                    category = rec.genre,
                                    duration = 200,
                                    lyrics = "[00:01] (AI Recommended track: '${rec.title}' by ${rec.artist})\n[00:10] Match reason: ${rec.reason}",
                                    isTrending = false,
                                    isNewRelease = false,
                                    isPodcast = false,
                                    isRadio = false
                                )
                                Toast.makeText(context, "Added '${rec.title}' to list!", Toast.LENGTH_SHORT).show()
                            }
                        ) {
                            Icon(Icons.Default.Add, contentDescription = "Add Track", tint = CosmicCyan)
                        }
                    }
                }
            }
        }
    }
}

// --- SEARCH SCREEN ---
@Composable
fun SearchScreen(viewModel: MusicViewModel) {
    var searchQuery by remember { mutableStateOf("") }
    val allSongs by viewModel.allSongs.collectAsStateWithLifecycle()
    val language by viewModel.language.collectAsStateWithLifecycle()

    val context = LocalContext.current

    val filteredSongs = remember(searchQuery, allSongs) {
        if (searchQuery.trim().isEmpty()) {
            emptyList()
        } else {
            allSongs.filter {
                it.title.contains(searchQuery, ignoreCase = true) ||
                it.artist.contains(searchQuery, ignoreCase = true) ||
                it.category.contains(searchQuery, ignoreCase = true)
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(SpaceBlack)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = if (language == "Hindi") "खोजें" else "Search Songs",
            fontWeight = FontWeight.Bold,
            fontSize = 24.sp,
            color = Color.White
        )

        // Voice and text input box
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Artists, songs, lyrics, podcasts...") },
                modifier = Modifier.weight(1f),
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = CosmicPurple) },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(Icons.Default.Close, contentDescription = "Clear", tint = Color.White)
                        }
                    }
                },
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = CosmicPurple,
                    unfocusedBorderColor = Color.White.copy(alpha = 0.2f)
                )
            )

            // Simulated Voice Search Button
            FilledIconButton(
                onClick = {
                    val voicesList = listOf("Blinding Lights", "Pop", "Rock", "Queen", "Eminem", "Podcast")
                    searchQuery = voicesList.random()
                    Toast.makeText(context, "Voice recognized: \"$searchQuery\"", Toast.LENGTH_SHORT).show()
                },
                colors = IconButtonDefaults.filledIconButtonColors(containerColor = CosmicPurple)
            ) {
                Icon(Icons.Default.Mic, contentDescription = "Voice Search", tint = Color.Black)
            }
        }

        if (searchQuery.trim().isEmpty()) {
            // Hot Categories shortcuts
            Text("Browse All Categories", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 16.sp)
            val categories = listOf("Pop", "Rock", "Hip-Hop", "Classical", "Electronic", "Jazz", "Podcasts", "Radio")
            
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(categories) { cat ->
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(80.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(
                                Brush.linearGradient(
                                    listOf(
                                        when (cat) {
                                            "Pop" -> CosmicPurple
                                            "Rock" -> Color(0xFFD62246)
                                            "Hip-Hop" -> CosmicCyan
                                            "Classical" -> Color(0xFFC77DFF)
                                            "Electronic" -> CyberPink
                                            "Jazz" -> Color(0xFF0077B6)
                                            "Podcasts" -> Color(0xFF8338EC)
                                            else -> Color(0xFFFB5607)
                                        }, Color.Black.copy(alpha = 0.7f)
                                    )
                                )
                            )
                            .clickable { searchQuery = cat }
                            .padding(14.dp),
                        contentAlignment = Alignment.BottomStart
                    ) {
                        Text(cat, fontWeight = FontWeight.Bold, color = Color.White, fontSize = 15.sp)
                    }
                }
            }
        } else {
            // Results List
            if (filteredSongs.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("No results match \"$searchQuery\"", color = Color.White.copy(alpha = 0.5f))
                }
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(filteredSongs) { song ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(DarkSlateCard, RoundedCornerShape(10.dp))
                                .clickable { viewModel.selectSongAndPlay(song, filteredSongs) }
                                .padding(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            AlbumArtComponent(seed = song.imageUrl, modifier = Modifier.size(50.dp))
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(song.title, fontWeight = FontWeight.Bold, color = Color.White, fontSize = 14.sp)
                                Text("${song.artist} • ${song.category}", color = Color.White.copy(alpha = 0.5f), fontSize = 11.sp)
                            }
                            IconButton(onClick = { viewModel.selectSongAndPlay(song, filteredSongs) }) {
                                Icon(Icons.Default.PlayArrow, contentDescription = "Play", tint = CosmicCyan)
                            }
                        }
                    }
                }
            }
        }
    }
}

// --- LIBRARY SCREEN ---
@Composable
fun LibraryScreen(viewModel: MusicViewModel) {
    val playlists by viewModel.playlists.collectAsStateWithLifecycle()
    val favorites by viewModel.favoriteSongs.collectAsStateWithLifecycle()
    val downloadedSongs by viewModel.downloadedSongs.collectAsStateWithLifecycle()
    val language by viewModel.language.collectAsStateWithLifecycle()

    var showCreateDialog by remember { mutableStateOf(false) }
    var playlistNameInput by remember { mutableStateOf("") }

    var selectedPlaylistForDetail by remember { mutableStateOf<PlaylistEntity?>(null) }
    val playlistSongsDetail by if (selectedPlaylistForDetail != null) {
        viewModel.getSongsInPlaylist(selectedPlaylistForDetail!!.id).collectAsStateWithLifecycle(initialValue = emptyList())
    } else {
        remember { mutableStateOf<List<SongEntity>>(emptyList()) }
    }

    val context = LocalContext.current

    if (showCreateDialog) {
        AlertDialog(
            onDismissRequest = { showCreateDialog = false },
            title = { Text("Create New Playlist") },
            text = {
                OutlinedTextField(
                    value = playlistNameInput,
                    onValueChange = { playlistNameInput = it },
                    placeholder = { Text("My Gym Hits, Chill coding loop, etc.") },
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (playlistNameInput.trim().isNotEmpty()) {
                            viewModel.createPlaylist(playlistNameInput)
                            playlistNameInput = ""
                            showCreateDialog = false
                            Toast.makeText(context, "Playlist created!", Toast.LENGTH_SHORT).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CosmicPurple, contentColor = Color.Black)
                ) {
                    Text("Create", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showCreateDialog = false }) {
                    Text("Cancel", color = Color.White)
                }
            },
            containerColor = DarkSlateSurface
        )
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(SpaceBlack)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        if (selectedPlaylistForDetail != null) {
            // --- PLAYLIST TRACKS DRILL DOWN ---
            item {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    IconButton(onClick = { selectedPlaylistForDetail = null }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                    Text(selectedPlaylistForDetail!!.name, fontWeight = FontWeight.Bold, fontSize = 22.sp, color = CosmicPurple)
                }
            }

            if (playlistSongsDetail.isEmpty()) {
                item {
                    Column(
                        modifier = Modifier.fillMaxWidth().padding(40.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(Icons.Default.MusicNote, contentDescription = null, modifier = Modifier.size(48.dp), tint = Color.White.copy(alpha = 0.3f))
                        Spacer(modifier = Modifier.height(12.dp))
                        Text("No songs in this playlist yet.", color = Color.White.copy(alpha = 0.5f))
                        Text("Go to Home, tap a song, and add it here!", fontSize = 11.sp, color = Color.White.copy(alpha = 0.4f))
                    }
                }
            } else {
                items(playlistSongsDetail) { song ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(DarkSlateCard, RoundedCornerShape(10.dp))
                            .clickable { viewModel.selectSongAndPlay(song, playlistSongsDetail) }
                            .padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        AlbumArtComponent(seed = song.imageUrl, modifier = Modifier.size(50.dp))
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(song.title, fontWeight = FontWeight.Bold, color = Color.White, fontSize = 14.sp)
                            Text(song.artist, color = Color.White.copy(alpha = 0.5f), fontSize = 11.sp)
                        }
                        IconButton(
                            onClick = {
                                viewModel.removeSongFromPlaylist(selectedPlaylistForDetail!!.id, song.id)
                                Toast.makeText(context, "Removed from playlist", Toast.LENGTH_SHORT).show()
                            }
                        ) {
                            Icon(Icons.Default.Delete, contentDescription = "Remove", tint = Color.Red)
                        }
                    }
                }
            }
        } else {
            // --- GENERAL LIBRARY HOMEPAGE ---
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (language == "Hindi") "आपकी लाइब्रेरी" else "Your Library",
                        fontWeight = FontWeight.Bold,
                        fontSize = 24.sp,
                        color = Color.White
                    )

                    Button(
                        onClick = { showCreateDialog = true },
                        colors = ButtonDefaults.buttonColors(containerColor = CosmicPurple, contentColor = Color.Black),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Create", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
            }

            // --- FAVORITES SECTION ---
            item {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.padding(top = 8.dp)
                ) {
                    Icon(Icons.Default.Favorite, contentDescription = null, tint = CyberPink)
                    Text(
                        text = if (language == "Hindi") "पसंदीदा गाने (${favorites.size})" else "Liked Songs (${favorites.size})",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        color = Color.White
                    )
                }
            }

            if (favorites.isEmpty()) {
                item {
                    Text("No liked songs yet. Tap the heart icon on any song!", color = Color.White.copy(alpha = 0.5f), fontSize = 13.sp)
                }
            } else {
                items(favorites) { song ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(DarkSlateCard, RoundedCornerShape(10.dp))
                            .clickable { viewModel.selectSongAndPlay(song, favorites) }
                            .padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        AlbumArtComponent(seed = song.imageUrl, modifier = Modifier.size(50.dp))
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(song.title, fontWeight = FontWeight.Bold, color = Color.White, fontSize = 14.sp)
                            Text(song.artist, color = Color.White.copy(alpha = 0.5f), fontSize = 12.sp)
                        }
                        IconButton(onClick = { viewModel.selectSongAndPlay(song, favorites) }) {
                            Icon(Icons.Default.PlayArrow, contentDescription = "Play", tint = CosmicCyan)
                        }
                    }
                }
            }

            // --- PLAYLISTS SECTION ---
            item {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.padding(top = 12.dp)
                ) {
                    Icon(Icons.Default.PlaylistPlay, contentDescription = null, tint = CosmicCyan)
                    Text("Playlists (${playlists.size})", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = Color.White)
                }
            }

            if (playlists.isEmpty()) {
                item {
                    Text("Create a playlist using the top-right button!", color = Color.White.copy(alpha = 0.5f), fontSize = 13.sp)
                }
            } else {
                items(playlists) { playlist ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(DarkSlateCard, RoundedCornerShape(10.dp))
                            .clickable { selectedPlaylistForDetail = playlist }
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            AlbumArtComponent(seed = "playlist_${playlist.name}", modifier = Modifier.size(48.dp))
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(playlist.name, fontWeight = FontWeight.Bold, color = Color.White, fontSize = 15.sp)
                                Text("Playlist", fontSize = 11.sp, color = Color.White.copy(alpha = 0.5f))
                            }
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(
                                onClick = {
                                    viewModel.deletePlaylist(playlist.id)
                                    Toast.makeText(context, "Playlist deleted", Toast.LENGTH_SHORT).show()
                                }
                            ) {
                                Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color.Red.copy(alpha = 0.7f))
                            }
                        }
                    }
                }
            }

            // --- DOWNLOADS SECTION ---
            item {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.padding(top = 12.dp)
                ) {
                    Icon(Icons.Default.CloudDownload, contentDescription = null, tint = CosmicPurple)
                    Text("Downloaded Offline Songs (${downloadedSongs.size})", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = Color.White)
                }
            }

            if (downloadedSongs.isEmpty()) {
                item {
                    Text("No downloaded songs yet. Tap download in player to listen offline!", color = Color.White.copy(alpha = 0.5f), fontSize = 13.sp)
                }
            } else {
                items(downloadedSongs) { song ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(DarkSlateCard, RoundedCornerShape(10.dp))
                            .clickable { viewModel.selectSongAndPlay(song, downloadedSongs) }
                            .padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        AlbumArtComponent(seed = song.imageUrl, modifier = Modifier.size(50.dp))
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(song.title, fontWeight = FontWeight.Bold, color = Color.White, fontSize = 14.sp)
                            Text(song.artist, color = Color.White.copy(alpha = 0.5f), fontSize = 12.sp)
                        }
                        IconButton(onClick = { viewModel.selectSongAndPlay(song, downloadedSongs) }) {
                            Icon(Icons.Default.PlayArrow, contentDescription = "Play", tint = CosmicCyan)
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(40.dp))
        }
    }
}

// --- PREMIUM PLAN SCREEN ---
@Composable
fun PremiumScreen(viewModel: MusicViewModel) {
    val isPremium by viewModel.isPremium.collectAsStateWithLifecycle()
    val language by viewModel.language.collectAsStateWithLifecycle()

    val context = LocalContext.current

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(SpaceBlack)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        item {
            Text(
                text = "BeatStream Premium",
                fontWeight = FontWeight.Bold,
                fontSize = 26.sp,
                color = CosmicPurple
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = if (isPremium) "You are currently a Premium Member! Enjoy ad-free audio." else "Unlock Lossless 320kbps Audio & Unlimited Downloads",
                color = Color.White.copy(alpha = 0.6f),
                textAlign = TextAlign.Center,
                fontSize = 14.sp
            )
        }

        // Feature cards
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = DarkSlateCard)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Premium Capabilities Included:", fontWeight = FontWeight.Bold, color = CosmicCyan, fontSize = 16.sp)
                    
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = CosmicCyan)
                        Text("Ad-Free Music Playback", color = Color.White, fontSize = 13.sp)
                    }
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = CosmicCyan)
                        Text("High Quality Audio (320 kbps / FLAC Lossless)", color = Color.White, fontSize = 13.sp)
                    }
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = CosmicCyan)
                        Text("Unlimited Offline Downloads", color = Color.White, fontSize = 13.sp)
                    }
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = CosmicCyan)
                        Text("Exclusive Albums & Podcasts early access", color = Color.White, fontSize = 13.sp)
                    }
                }
            }
        }

        // Plan Selection Box
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(
                        Brush.linearGradient(
                            listOf(Color(0xFF2E0854), Color(0xFF130225))
                        )
                    )
                    .border(2.dp, CosmicPurple, RoundedCornerShape(16.dp))
                    .padding(20.dp)
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("POPULAR CHOICE", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = CosmicCyan)
                    Text("Individual Unlimited Monthly", fontWeight = FontWeight.Bold, fontSize = 20.sp, color = Color.White)
                    
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("$1.99", fontSize = 34.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        Text("/ month", color = Color.White.copy(alpha = 0.5f), fontSize = 14.sp)
                    }

                    Text("Cancel anytime. No commitment required.", fontSize = 11.sp, color = Color.White.copy(alpha = 0.5f))

                    Button(
                        onClick = {
                            viewModel.setPremiumStatus(!isPremium)
                            val msg = if (!isPremium) "Successfully subscribed to BeatStream Premium!" else "Premium subscription cancelled."
                            Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = CosmicPurple, contentColor = Color.Black),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth().height(48.dp)
                    ) {
                        Text(
                            text = if (isPremium) "Unsubscribe Plan" else "Subscribe Now ($1.99/mo)",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                    }
                }
            }
        }

        // Student Offer Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = DarkSlateCard)
            ) {
                Row(
                    modifier = Modifier.padding(16.dp).fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Student discount tier", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 14.sp)
                        Text("Verify college credentials for 50% discount", fontSize = 12.sp, color = Color.White.copy(alpha = 0.6f))
                    }
                    OutlinedButton(
                        onClick = { Toast.makeText(context, "Student verification open", Toast.LENGTH_SHORT).show() },
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = CosmicCyan)
                    ) {
                        Text("Verify", fontSize = 11.sp)
                    }
                }
            }
        }
    }
}

// --- PROFILE & ADMIN SCREEN ---
@Composable
fun ProfileScreen(viewModel: MusicViewModel) {
    val username by viewModel.username.collectAsStateWithLifecycle()
    val email by viewModel.userEmail.collectAsStateWithLifecycle()
    val isPremium by viewModel.isPremium.collectAsStateWithLifecycle()
    val allSongs by viewModel.allSongs.collectAsStateWithLifecycle()
    val language by viewModel.language.collectAsStateWithLifecycle()

    val context = LocalContext.current

    // Admin panel form states
    var adminTitleInput by remember { mutableStateOf("") }
    var adminArtistInput by remember { mutableStateOf("") }
    var adminAlbumInput by remember { mutableStateOf("") }
    var adminGenreInput by remember { mutableStateOf("Pop") }
    var adminLyricsInput by remember { mutableStateOf("") }
    var adminIsPodcast by remember { mutableStateOf(false) }
    var adminIsRadio by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(SpaceBlack)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        // PROFILE CARD Header
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(DarkSlateCard, RoundedCornerShape(16.dp))
                    .padding(20.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                AlbumArtComponent(seed = username, modifier = Modifier.size(70.dp), isRounded = true)
                Spacer(modifier = Modifier.width(18.dp))
                Column {
                    Text(username, fontWeight = FontWeight.Bold, fontSize = 20.sp, color = Color.White)
                    Text(email, fontSize = 13.sp, color = Color.White.copy(alpha = 0.5f))
                    
                    Spacer(modifier = Modifier.height(6.dp))
                    
                    Badge(
                        containerColor = if (isPremium) CosmicPurple else Color.Gray,
                        contentColor = if (isPremium) Color.Black else Color.White
                    ) {
                        Text(
                            text = if (isPremium) "PREMIUM MEMBER" else "FREE TIER PLAN",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
            }
        }

        // --- GENERAL PREFERENCES SECTION ---
        item {
            Text("Settings & Customization", fontWeight = FontWeight.Bold, color = CosmicCyan, fontSize = 16.sp)
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = DarkSlateCard)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    // Language settings
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("App Language", color = Color.White, fontSize = 14.sp)
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            FilterChip(
                                selected = language == "English",
                                onClick = { viewModel.setLanguage("English") },
                                label = { Text("English", fontSize = 11.sp) }
                            )
                            FilterChip(
                                selected = language == "Hindi",
                                onClick = { viewModel.setLanguage("Hindi") },
                                label = { Text("Hindi", fontSize = 11.sp) }
                            )
                        }
                    }

                    Divider(color = Color.White.copy(alpha = 0.1f))

                    // Theme selector
                    val darkState by viewModel.isDarkTheme.collectAsStateWithLifecycle()
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Dark Cyber Theme", color = Color.White, fontSize = 14.sp)
                        Switch(
                            checked = darkState,
                            onCheckedChange = { viewModel.setDarkTheme(it) },
                            colors = SwitchDefaults.colors(checkedThumbColor = CosmicPurple)
                        )
                    }

                    Divider(color = Color.White.copy(alpha = 0.1f))

                    // Logout Button
                    Button(
                        onClick = {
                            viewModel.logout()
                            Toast.makeText(context, "Logged out safely", Toast.LENGTH_SHORT).show()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color.Red.copy(alpha = 0.8f), contentColor = Color.White),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Logout Profile Session", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // --- ADMIN PANEL FOR SONGS UPLOAD ---
        item {
            Text("Admin Dashboard Panel", fontWeight = FontWeight.Bold, color = CosmicPurple, fontSize = 18.sp)
            Spacer(modifier = Modifier.height(2.dp))
            Text("Inject tracks, podcasts, and radio stations directly into SQLite Room", fontSize = 11.sp, color = Color.White.copy(alpha = 0.5f))
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = DarkSlateCard)
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text("Upload New Music Track / Item", fontWeight = FontWeight.Bold, color = CosmicCyan, fontSize = 14.sp)

                    OutlinedTextField(
                        value = adminTitleInput,
                        onValueChange = { adminTitleInput = it },
                        label = { Text("Song Title / Name", fontSize = 12.sp) },
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = adminArtistInput,
                        onValueChange = { adminArtistInput = it },
                        label = { Text("Artist / Broadcaster Name", fontSize = 12.sp) },
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = adminAlbumInput,
                        onValueChange = { adminAlbumInput = it },
                        label = { Text("Album Name", fontSize = 12.sp) },
                        modifier = Modifier.fillMaxWidth()
                    )

                    // Type checkboxes
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(checked = adminIsPodcast, onCheckedChange = { adminIsPodcast = it })
                            Text("Podcast", color = Color.White, fontSize = 11.sp)
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(checked = adminIsRadio, onCheckedChange = { adminIsRadio = it })
                            Text("Radio Station", color = Color.White, fontSize = 11.sp)
                        }
                    }

                    if (!adminIsPodcast && !adminIsRadio) {
                        // Genre selection
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Category:", color = Color.White, fontSize = 13.sp)
                            val genresList = listOf("Pop", "Rock", "Hip-Hop", "Classical", "Electronic", "Jazz")
                            Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                genresList.forEach { g ->
                                    FilterChip(
                                        selected = adminGenreInput == g,
                                        onClick = { adminGenreInput = g },
                                        label = { Text(g, fontSize = 10.sp) }
                                    )
                                }
                            }
                        }
                    }

                    OutlinedTextField(
                        value = adminLyricsInput,
                        onValueChange = { adminLyricsInput = it },
                        label = { Text("Song Synced Lyrics (LRC format or raw)", fontSize = 12.sp) },
                        modifier = Modifier.fillMaxWidth(),
                        maxLines = 3
                    )

                    Button(
                        onClick = {
                            if (adminTitleInput.trim().isNotEmpty() && adminArtistInput.trim().isNotEmpty()) {
                                val cat = when {
                                    adminIsPodcast -> "Podcasts"
                                    adminIsRadio -> "Radio"
                                    else -> adminGenreInput
                                }
                                val dur = if (adminIsRadio) 0L else 240L
                                viewModel.addCustomSong(
                                    title = adminTitleInput,
                                    artist = adminArtistInput,
                                    album = adminAlbumInput.ifEmpty { "Single" },
                                    category = cat,
                                    duration = dur,
                                    lyrics = adminLyricsInput,
                                    isTrending = true,
                                    isNewRelease = true,
                                    isPodcast = adminIsPodcast,
                                    isRadio = adminIsRadio
                                )
                                // Clear inputs
                                adminTitleInput = ""
                                adminArtistInput = ""
                                adminAlbumInput = ""
                                adminLyricsInput = ""
                                Toast.makeText(context, "Track inserted in DB!", Toast.LENGTH_SHORT).show()
                            } else {
                                Toast.makeText(context, "Title and Artist are mandatory!", Toast.LENGTH_SHORT).show()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = CosmicCyan, contentColor = Color.Black),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Add to Database", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // --- SONG INVENTORY CONTROL ---
        item {
            Text("Database Song Inventory (${allSongs.size} tracks)", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 15.sp)
        }

        items(allSongs) { song ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(DarkSlateCard, RoundedCornerShape(10.dp))
                    .padding(8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    AlbumArtComponent(seed = song.imageUrl, modifier = Modifier.size(40.dp))
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(song.title, fontWeight = FontWeight.Bold, color = Color.White, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text("${song.artist} • ${song.category}", color = Color.White.copy(alpha = 0.5f), fontSize = 11.sp, maxLines = 1)
                    }
                }

                IconButton(
                    onClick = {
                        viewModel.deleteSong(song.id)
                        Toast.makeText(context, "Track purged", Toast.LENGTH_SHORT).show()
                    }
                ) {
                    Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color.Red.copy(alpha = 0.8f))
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(40.dp))
        }
    }
}

// --- FULL PREMIUM PLAYER SCREEN (EXPANDABLE BOTTOM SHEET OVERLAY) ---
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FullPlayerScreen(
    song: SongEntity,
    viewModel: MusicViewModel,
    onDismiss: () -> Unit
) {
    val isPlaying by viewModel.isPlaying.collectAsStateWithLifecycle()
    val progress by viewModel.currentProgress.collectAsStateWithLifecycle()
    val isShuffle by viewModel.isShuffle.collectAsStateWithLifecycle()
    val isRepeat by viewModel.isRepeat.collectAsStateWithLifecycle()
    val speed by viewModel.playbackSpeed.collectAsStateWithLifecycle()
    val isFav by viewModel.isSongFavorite(song.id).collectAsStateWithLifecycle(initialValue = false)
    val isDownloaded by viewModel.isSongDownloaded(song.id).collectAsStateWithLifecycle(initialValue = false)

    // Advanced controls toggles
    var showLyricsPanel by remember { mutableStateOf(false) }
    var showEqualizerPanel by remember { mutableStateOf(false) }
    var showTimerPanel by remember { mutableStateOf(false) }
    var showPlaylistPicker by remember { mutableStateOf(false) }

    val context = LocalContext.current

    val totalDuration = if (song.duration == 0L) 300L else song.duration
    val progressFraction = progress.toFloat() / totalDuration.toFloat()

    // Formatted timers
    val currentFormatted = remember(progress) {
        val mins = progress / 60
        val secs = progress % 60
        String.format("%02d:%02d", mins, secs)
    }
    val totalFormatted = remember(song.duration) {
        if (song.duration == 0L) {
            "LIVE"
        } else {
            val mins = song.duration / 60
            val secs = song.duration % 60
            String.format("%02d:%02d", mins, secs)
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(Color(0xFF131520), SpaceBlack)
                )
            )
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(20.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Player Top Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.KeyboardArrowDown, contentDescription = "Collapse Player", tint = Color.White, modifier = Modifier.size(32.dp))
                }
                
                Text(
                    text = if (song.isRadio) "LIVE BROADCAST" else if (song.isPodcast) "PODCAST SHOW" else "NOW PLAYING",
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    color = CosmicPurple,
                    letterSpacing = 2.sp
                )

                IconButton(
                    onClick = {
                        val shareIntent = "Playing: ${song.title} by ${song.artist} on BeatStream Music Player!"
                        Toast.makeText(context, "QR Code & link generated for: \"$shareIntent\"", Toast.LENGTH_SHORT).show()
                    }
                ) {
                    Icon(Icons.Default.QrCode2, contentDescription = "Share QR Code", tint = Color.White)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Massive Album Artwork (Breathing Animation during playback)
            val infiniteTransition = rememberInfiniteTransition(label = "rotation")
            val rotationAngle by infiniteTransition.animateFloat(
                initialValue = 0f,
                targetValue = 360f,
                animationSpec = infiniteRepeatable(
                    animation = tween(15000, easing = LinearEasing),
                    repeatMode = RepeatMode.Restart
                ),
                label = "rotation"
            )

            Box(
                modifier = Modifier
                    .size(260.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .rotate(if (isPlaying && !song.isRadio) rotationAngle else 0f)
                    .background(DarkSlateCard),
                contentAlignment = Alignment.Center
            ) {
                AlbumArtComponent(
                    seed = song.imageUrl,
                    modifier = Modifier.fillMaxSize(),
                    iconSize = 72,
                    isRounded = !song.isRadio && !song.isPodcast
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Metadata Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = song.title,
                        fontWeight = FontWeight.Bold,
                        fontSize = 22.sp,
                        color = Color.White,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = song.artist,
                        fontSize = 16.sp,
                        color = Color.White.copy(alpha = 0.6f),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                IconButton(onClick = { viewModel.toggleFavorite(song.id, isFav) }) {
                    Icon(
                        imageVector = if (isFav) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                        contentDescription = "Favorite",
                        tint = if (isFav) CyberPink else Color.White,
                        modifier = Modifier.size(28.dp)
                    )
                }
            }

            // Scrubbing Slider bar
            Column(modifier = Modifier.fillMaxWidth()) {
                Slider(
                    value = progressFraction.coerceIn(0f, 1f),
                    onValueChange = {
                        val targetSeconds = (it * totalDuration).toLong()
                        viewModel.seekTo(targetSeconds)
                    },
                    colors = SliderDefaults.colors(
                        activeTrackColor = CosmicCyan,
                        thumbColor = CosmicCyan,
                        inactiveTrackColor = Color.White.copy(alpha = 0.15f)
                    )
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(currentFormatted, fontSize = 11.sp, color = Color.White.copy(alpha = 0.5f))
                    Text(totalFormatted, fontSize = 11.sp, color = Color.White.copy(alpha = 0.5f))
                }
            }

            // Main playback buttons row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { viewModel.toggleShuffle() }) {
                    Icon(
                        imageVector = Icons.Default.Shuffle,
                        contentDescription = "Shuffle",
                        tint = if (isShuffle) CosmicCyan else Color.White.copy(alpha = 0.5f)
                    )
                }

                IconButton(onClick = { viewModel.previousSong() }) {
                    Icon(Icons.Default.SkipPrevious, contentDescription = "Previous", tint = Color.White, modifier = Modifier.size(36.dp))
                }

                IconButton(onClick = { viewModel.togglePlayPause() }) {
                    Icon(
                        imageVector = if (isPlaying) Icons.Default.PauseCircleFilled else Icons.Default.PlayCircleFilled,
                        contentDescription = "Play/Pause",
                        tint = CosmicPurple,
                        modifier = Modifier.size(72.dp)
                    )
                }

                IconButton(onClick = { viewModel.nextSong() }) {
                    Icon(Icons.Default.SkipNext, contentDescription = "Next", tint = Color.White, modifier = Modifier.size(36.dp))
                }

                IconButton(onClick = { viewModel.toggleRepeat() }) {
                    Icon(
                        imageVector = Icons.Default.Repeat,
                        contentDescription = "Repeat",
                        tint = if (isRepeat) CosmicCyan else Color.White.copy(alpha = 0.5f)
                    )
                }
            }

            // Premium HUD Controls bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(DarkSlateCard, RoundedCornerShape(12.dp))
                    .padding(8.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Download
                IconButton(onClick = {
                    viewModel.toggleDownload(song.id, isDownloaded)
                    val act = if (!isDownloaded) "Downloaded" else "Removed download"
                    Toast.makeText(context, "$act '${song.title}' for offline listening!", Toast.LENGTH_SHORT).show()
                }) {
                    Icon(
                        imageVector = if (isDownloaded) Icons.Default.FileDownloadDone else Icons.Default.FileDownload,
                        contentDescription = "Download Offline",
                        tint = if (isDownloaded) CosmicCyan else Color.White
                    )
                }

                // Add to Playlist picker trigger
                IconButton(onClick = { showPlaylistPicker = true }) {
                    Icon(Icons.Default.PlaylistAdd, contentDescription = "Add to playlist", tint = Color.White)
                }

                // Lyrics trigger
                IconButton(onClick = {
                    showLyricsPanel = !showLyricsPanel
                    showEqualizerPanel = false
                    showTimerPanel = false
                }) {
                    Icon(
                        imageVector = Icons.Default.Lyrics,
                        contentDescription = "Show Lyrics",
                        tint = if (showLyricsPanel) CosmicPurple else Color.White
                    )
                }

                // Equalizer trigger
                IconButton(onClick = {
                    showEqualizerPanel = !showEqualizerPanel
                    showLyricsPanel = false
                    showTimerPanel = false
                }) {
                    Icon(
                        imageVector = Icons.Default.Tune,
                        contentDescription = "Equalizer Panel",
                        tint = if (showEqualizerPanel) CosmicCyan else Color.White
                    )
                }

                // Timer trigger
                IconButton(onClick = {
                    showTimerPanel = !showTimerPanel
                    showLyricsPanel = false
                    showEqualizerPanel = false
                }) {
                    Icon(
                        imageVector = Icons.Default.Timer,
                        contentDescription = "Sleep Timer",
                        tint = if (showTimerPanel) CosmicPurple else Color.White
                    )
                }
            }

            // PANEL EXPANSIONS (Crossfades)
            AnimatedVisibility(visible = showLyricsPanel) {
                LyricsCard(lyrics = song.lyrics, progress = progress)
            }

            AnimatedVisibility(visible = showEqualizerPanel) {
                EqualizerCard(viewModel = viewModel)
            }

            AnimatedVisibility(visible = showTimerPanel) {
                TimerCard(viewModel = viewModel)
            }

            AnimatedVisibility(visible = showPlaylistPicker) {
                PlaylistPickerCard(
                    songId = song.id,
                    viewModel = viewModel,
                    onClose = { showPlaylistPicker = false }
                )
            }

            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}

// --- SUB PANEL: LIVE SCROLLING LYRICS ---
@Composable
fun LyricsCard(lyrics: String, progress: Long) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = DarkSlateCard),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Default.Lyrics, contentDescription = null, tint = CosmicPurple)
                Text("Live Dynamic Lyrics", fontWeight = FontWeight.Bold, color = CosmicPurple, fontSize = 14.sp)
            }

            val lyricsLines = remember(lyrics) { lyrics.split("\n") }

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    lyricsLines.forEach { line ->
                        // Simple LRC formatting match: [00:15] text
                        val isHighlighted = remember(line, progress) {
                            if (line.startsWith("[")) {
                                val minutes = line.substring(1, 3).toLongOrNull() ?: 0L
                                val seconds = line.substring(4, 6).toLongOrNull() ?: 0L
                                val timestamp = minutes * 60 + seconds
                                progress >= timestamp && progress < timestamp + 10
                            } else {
                                false
                            }
                        }

                        val cleanText = if (line.startsWith("[")) line.substringAfter("] ") else line
                        Text(
                            text = cleanText,
                            color = if (isHighlighted) CosmicCyan else Color.White.copy(alpha = 0.5f),
                            fontWeight = if (isHighlighted) FontWeight.Bold else FontWeight.Normal,
                            fontSize = if (isHighlighted) 15.sp else 13.sp,
                            modifier = Modifier.fillMaxWidth(),
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        }
    }
}

// --- SUB PANEL: PROFESSIONAL AUDIO EQUALIZER ---
@Composable
fun EqualizerCard(viewModel: MusicViewModel) {
    val bass by viewModel.equalizerBass.collectAsStateWithLifecycle()
    val mid by viewModel.equalizerMid.collectAsStateWithLifecycle()
    val treble by viewModel.equalizerTreble.collectAsStateWithLifecycle()
    val speed by viewModel.playbackSpeed.collectAsStateWithLifecycle()

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = DarkSlateCard),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Default.Tune, contentDescription = null, tint = CosmicCyan)
                Text("Pro Equalizer & Playback Speed", fontWeight = FontWeight.Bold, color = CosmicCyan, fontSize = 14.sp)
            }

            // Playback speed chips
            Text("Playback Speed Rate:", fontSize = 12.sp, color = Color.White)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                listOf(0.5f, 1.0f, 1.5f, 2.0f).forEach { rate ->
                    FilterChip(
                        selected = speed == rate,
                        onClick = { viewModel.setPlaybackSpeed(rate) },
                        label = { Text("${rate}x", fontSize = 11.sp) }
                    )
                }
            }

            Divider(color = Color.White.copy(alpha = 0.1f))

            Text("Equalizer Frequencies (Bass, Mid, Treble):", fontSize = 12.sp, color = Color.White)

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                // Bass Slider
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(modifier = Modifier.height(110.dp), contentAlignment = Alignment.Center) {
                        Slider(
                            value = bass,
                            onValueChange = { viewModel.updateEqualizer(it, mid, treble) },
                            modifier = Modifier.rotate(-90f).width(100.dp),
                            colors = SliderDefaults.colors(activeTrackColor = CosmicPurple, thumbColor = CosmicPurple)
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("BASS", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = Color.White)
                }

                // Mid Slider
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(modifier = Modifier.height(110.dp), contentAlignment = Alignment.Center) {
                        Slider(
                            value = mid,
                            onValueChange = { viewModel.updateEqualizer(bass, it, treble) },
                            modifier = Modifier.rotate(-90f).width(100.dp),
                            colors = SliderDefaults.colors(activeTrackColor = CosmicCyan, thumbColor = CosmicCyan)
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("MID", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = Color.White)
                }

                // Treble Slider
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(modifier = Modifier.height(110.dp), contentAlignment = Alignment.Center) {
                        Slider(
                            value = treble,
                            onValueChange = { viewModel.updateEqualizer(bass, mid, it) },
                            modifier = Modifier.rotate(-90f).width(100.dp),
                            colors = SliderDefaults.colors(activeTrackColor = CyberPink, thumbColor = CyberPink)
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("TREBLE", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = Color.White)
                }
            }
        }
    }
}

// --- SUB PANEL: SLEEP TIMER COUNTDOWN ---
@Composable
fun TimerCard(viewModel: MusicViewModel) {
    val activeTimerMinutes by viewModel.sleepTimerMinutes.collectAsStateWithLifecycle()
    val secondsLeft by viewModel.sleepTimerSecondsLeft.collectAsStateWithLifecycle()

    val context = LocalContext.current

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = DarkSlateCard),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Default.Timer, contentDescription = null, tint = CosmicPurple)
                Text("Sleep Playback Timer", fontWeight = FontWeight.Bold, color = CosmicPurple, fontSize = 14.sp)
            }

            if (secondsLeft > 0) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Music will pause automatically in: ${secondsLeft / 60}m ${secondsLeft % 60}s",
                        fontSize = 12.sp,
                        color = CosmicCyan
                    )
                    TextButton(onClick = {
                        viewModel.setSleepTimer(0)
                        Toast.makeText(context, "Sleep timer deactivated", Toast.LENGTH_SHORT).show()
                    }) {
                        Text("Disable", color = Color.Red)
                    }
                }
            } else {
                Text("Select when playback should automatically pause:", fontSize = 12.sp, color = Color.White)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf(1, 5, 10, 30, 60).forEach { mins ->
                        FilterChip(
                            selected = activeTimerMinutes == mins,
                            onClick = {
                                viewModel.setSleepTimer(mins)
                                Toast.makeText(context, "Timer set for $mins minutes", Toast.LENGTH_SHORT).show()
                            },
                            label = { Text("${mins}m") }
                        )
                    }
                }
            }
        }
    }
}

// --- SUB PANEL: PLAYLIST CHOOSE EXPANSION ---
@Composable
fun PlaylistPickerCard(
    songId: Int,
    viewModel: MusicViewModel,
    onClose: () -> Unit
) {
    val playlists by viewModel.playlists.collectAsStateWithLifecycle()
    val context = LocalContext.current

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = DarkSlateCard),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Add Track to Playlist", fontWeight = FontWeight.Bold, color = CosmicCyan, fontSize = 14.sp)
                IconButton(onClick = onClose) {
                    Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White)
                }
            }

            if (playlists.isEmpty()) {
                Text("No playlists found. Create one in the Library tab!", fontSize = 12.sp, color = Color.White.copy(alpha = 0.5f))
            } else {
                LazyColumn(
                    modifier = Modifier.heightIn(max = 150.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(playlists) { playlist ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(SpaceBlack.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                                .clickable {
                                    viewModel.addSongToPlaylist(playlist.id, songId)
                                    Toast.makeText(context, "Track added to '${playlist.name}'!", Toast.LENGTH_SHORT).show()
                                    onClose()
                                }
                                .padding(10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(playlist.name, color = Color.White, fontSize = 13.sp)
                            Icon(Icons.Default.AddCircle, contentDescription = "Add", tint = CosmicCyan)
                        }
                    }
                }
            }
        }
    }
}
