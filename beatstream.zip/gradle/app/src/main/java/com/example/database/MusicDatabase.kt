package com.example.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        SongEntity::class,
        PlaylistEntity::class,
        PlaylistSongEntity::class,
        FavoriteEntity::class,
        HistoryEntity::class,
        DownloadEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class MusicDatabase : RoomDatabase() {
    abstract fun musicDao(): MusicDao

    companion object {
        @Volatile
        private var INSTANCE: MusicDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope): MusicDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    MusicDatabase::class.java,
                    "beatstream_database"
                )
                .addCallback(MusicDatabaseCallback(scope))
                .build()
                INSTANCE = instance
                instance
            }
        }
    }

    private class MusicDatabaseCallback(
        private val scope: CoroutineScope
    ) : RoomDatabase.Callback() {
        override fun onCreate(db: SupportSQLiteDatabase) {
            super.onCreate(db)
            INSTANCE?.let { database ->
                scope.launch(Dispatchers.IO) {
                    populateDatabase(database.musicDao())
                }
            }
        }

        private suspend fun populateDatabase(dao: MusicDao) {
            // Prepopulate starter pack of 12 beautiful songs across diverse genres
            val starterSongs = listOf(
                SongEntity(
                    title = "Blinding Lights",
                    artist = "The Weeknd",
                    album = "After Hours",
                    category = "Pop",
                    duration = 200,
                    imageUrl = "pop_blinding",
                    isTrending = true,
                    isNewRelease = false,
                    lyrics = """[00:01] (Instrumental Intro)
[00:15] Yeah, I've been on my own for long enough
[00:22] Maybe you can show me how to love, maybe
[00:28] I'm going through withdrawals
[00:32] You don't even have to do too much
[00:36] You can turn me on with just a touch, baby
[00:43] I look around and Sin City's cold and empty
[00:50] No one's around to judge me
[00:54] I can't see clearly when you're gone
[01:00] I said, ooh, I'm blinded by the lights
[01:06] No, I can't sleep until I feel your touch
[01:13] I said, ooh, I'm drowning in the night
[01:19] Oh, when I'm like this, you're the one I trust
[01:26] (Instrumental Outro)"""
                ),
                SongEntity(
                    title = "Shape of You",
                    artist = "Ed Sheeran",
                    album = "Divide",
                    category = "Pop",
                    duration = 233,
                    imageUrl = "pop_shape",
                    isTrending = false,
                    isNewRelease = true,
                    lyrics = """[00:01] (Chords Intro)
[00:08] The club isn't the best place to find a lover
[00:11] So the bar is where I go
[00:13] Me and my friends at the table doing shots
[00:15] Drinking fast and then we talk slow
[00:18] Come over and start up a conversation with just me
[00:21] And trust me I'll give it a chance now
[00:23] Take my hand, stop, put Van the Man on the jukebox
[00:25] And then we start to dance, and now I'm singing like
[00:28] Girl, you know I want your love
[00:30] Your love was handmade for somebody like me
[00:32] Come on now, follow my lead
[00:34] I may be crazy, don't mind me
[00:36] Say, boy, let's not talk too much
[00:38] Grab on my waist and put that body on me
[00:40] Come on now, follow my lead
[00:42] Come, come on now, follow my lead
[00:44] I'm in love with the shape of you
[00:47] We push and pull like a magnet do
[00:49] Although my heart is falling too
[00:51] I'm in love with your body"""
                ),
                SongEntity(
                    title = "In the End",
                    artist = "Linkin Park",
                    album = "Hybrid Theory",
                    category = "Rock",
                    duration = 216,
                    imageUrl = "rock_end",
                    isTrending = true,
                    isNewRelease = false,
                    lyrics = """[00:01] (Iconic Piano Intro)
[00:09] It starts with one thing, I don't know why
[00:12] It doesn't even matter how hard you try
[00:14] Keep that in mind, I designed this rhyme
[00:16] To explain in due time (All I know)
[00:19] Time is a valuable thing
[00:21] Watch it fly by as the pendulum swings
[00:23] Watch it count down to the end of the day
[00:25] The clock ticks life away (It's so unreal)
[00:28] It's so unreal, didn't look out below
[00:31] Watch the time go right out the window
[00:33] Trying to hold on, but didn't even know
[00:35] I wasted it all just to watch you go
[00:37] I kept everything inside
[00:39] And even though I tried, it all fell apart
[00:42] What it meant to me will eventually
[00:44] Be a memory of a time when I tried so hard
[01:00] I tried so hard and got so far
[01:06] But in the end, it doesn't even matter
[01:11] I had to fall to lose it all
[01:16] But in the end, it doesn't even matter"""
                ),
                SongEntity(
                    title = "Lose Yourself",
                    artist = "Eminem",
                    album = "8 Mile",
                    category = "Hip-Hop",
                    duration = 326,
                    imageUrl = "hiphop_lose",
                    isTrending = true,
                    isNewRelease = false,
                    lyrics = """[00:01] Look, if you had one shot, or one opportunity
[00:07] To seize everything you ever wanted in one moment
[00:13] Would you capture it, or just let it slip? Yo
[00:19] His palms are sweaty, knees weak, arms are heavy
[00:22] There's vomit on his sweater already, mom's spaghetti
[00:24] He's nervous, but on the surface he looks calm and ready to drop bombs
[00:27] But he keeps on forgetting what he wrote down, the whole crowd goes so loud
[00:31] He opens his mouth, but the words won't come out
[00:33] He's choking, how? Everybody's joking now
[00:35] The clock's run out, time's up, over, blaow!
[00:37] Snap back to reality, ope there goes gravity
[00:39] Ope, there goes Rabbit, he choked, he's so mad
[00:41] But he won't give up that easy, no, he won't have it
[00:43] He knows his whole back's to these ropes, it don't matter
[00:45] He's dope, he knows that, but he's broke, he's so stagnant
[00:48] You better lose yourself in the music
[00:50] The moment, you own it, you better never let it go
[00:53] You only get one shot, do not miss your chance to blow
[00:56] This opportunity comes once in a lifetime, yo"""
                ),
                SongEntity(
                    title = "God's Plan",
                    artist = "Drake",
                    album = "Scorpion",
                    category = "Hip-Hop",
                    duration = 198,
                    imageUrl = "hiphop_gods",
                    isTrending = false,
                    isNewRelease = true,
                    lyrics = """[00:01] (Beat Drops)
[00:08] Yeah, they wishin' and wishin' and wishin' and wishin'
[00:12] They wishin' on me, yeah
[00:15] I been movin' calm, don't start no trouble with me
[00:19] Tryna keep it peaceful is a struggle for me
[00:22] Don't pull up at 6 AM to cuddle with me
[00:25] You know how I like it when you lovin' on me
[00:29] I don't wanna die for them to miss me
[00:32] Yes, I see the things that they wishin' on me
[00:36] Hope I got some brothers that'll outlive me
[00:39] They gonna tell the story, shit was different with me
[00:42] God's plan, God's plan
[00:45] I hold back, sometimes I won't, yuh
[00:48] I feel good, sometimes I don't, ay, don't
[00:51] I finesse down Weston Road, ay, 'ness
[00:54] Might go down a G-O-D, yeah, wait
[00:57] I go hard on Southside G, yuh, Way
[01:00] I make sure that northside eat"""
                ),
                SongEntity(
                    title = "Clair de Lune",
                    artist = "Claude Debussy",
                    album = "Suite bergamasque",
                    category = "Classical",
                    duration = 305,
                    imageUrl = "classical_clair",
                    isTrending = false,
                    isNewRelease = false,
                    lyrics = "[00:01] [Instrumental - Soft orchestral piano solo - Impressionistic masterpiece]"
                ),
                SongEntity(
                    title = "Symphony No. 9",
                    artist = "Beethoven",
                    album = "Classic Masterworks",
                    category = "Classical",
                    duration = 420,
                    imageUrl = "classical_symphony",
                    isTrending = false,
                    isNewRelease = false,
                    lyrics = "[00:01] [Instrumental - Epic choral and orchestral crescendo - Ode to Joy theme begins]"
                ),
                SongEntity(
                    title = "Strobe",
                    artist = "Deadmau5",
                    album = "For Lack of a Better Name",
                    category = "Electronic",
                    duration = 360,
                    imageUrl = "electronic_strobe",
                    isTrending = false,
                    isNewRelease = true,
                    lyrics = "[00:01] [Instrumental - Ambient electronic synth swelling - Deep progressive chord transitions]"
                ),
                SongEntity(
                    title = "Animals",
                    artist = "Martin Garrix",
                    album = "Gold Skies",
                    category = "Electronic",
                    duration = 304,
                    imageUrl = "electronic_animals",
                    isTrending = true,
                    isNewRelease = false,
                    lyrics = "[00:01] [Instrumental - High energy electro-house beat building up to the main drops]"
                ),
                SongEntity(
                    title = "So What",
                    artist = "Miles Davis",
                    album = "Kind of Blue",
                    category = "Jazz",
                    duration = 561,
                    imageUrl = "jazz_sowhat",
                    isTrending = false,
                    isNewRelease = false,
                    lyrics = "[00:01] [Instrumental - Smooth Cool Jazz - Double bass intro leading to trumpet & sax solos]"
                ),
                SongEntity(
                    title = "Bohemian Rhapsody",
                    artist = "Queen",
                    album = "A Night at the Opera",
                    category = "Rock",
                    duration = 354,
                    imageUrl = "rock_bohemian",
                    isTrending = false,
                    isNewRelease = false,
                    lyrics = """[00:01] Is this the real life? Is this just fantasy?
[00:08] Caught in a landslide, no escape from reality
[00:15] Open your eyes, look up to the skies and see
[00:23] I'm just a poor boy, I need no sympathy
[00:30] Because I'm easy come, easy go, little high, little low
[00:37] Any way the wind blows doesn't really matter to me, to me
[00:50] Mama, just killed a man
[00:56] Put a gun against his head, pulled my trigger, now he's dead
[01:03] Mama, life had just begun
[01:09] But now I've gone and thrown it all away"""
                ),
                SongEntity(
                    title = "Despacito Remix",
                    artist = "Luis Fonsi ft. Daddy Yankee & Justin Bieber",
                    album = "Vida",
                    category = "Pop",
                    duration = 230,
                    imageUrl = "pop_despacito",
                    isTrending = true,
                    isNewRelease = false,
                    lyrics = """[00:01] Come on over in my direction
[00:05] So thankful for that, it's such a blessing, yeah
[00:10] Turn every situation into heaven, yeah
[00:15] Oh, you are my sunrise on the darkest day
[00:21] Got me feeling some kind of way
[00:24] Make me want to savor every moment slowly, slowly
[00:29] Despacito
[00:31] Quiero respirar tu cuello despacito
[00:35] Deja que te diga cosas al oído
[00:38] Para que te acuerdes si no estás conmigo"""
                ),
                // --- PODCASTS ---
                SongEntity(
                    title = "The Joe Rogan Experience - Episode #2041",
                    artist = "Joe Rogan",
                    album = "JRE Podcasts",
                    category = "Podcasts",
                    duration = 3600,
                    imageUrl = "podcast_jre",
                    isPodcast = true,
                    lyrics = """[00:01] Welcome to the Joe Rogan Experience.
[00:05] Today we are discussing space, astrophysics, and quantum computation with our guest..."""
                ),
                SongEntity(
                    title = "Lex Fridman Podcast - Sam Altman: OpenAI",
                    artist = "Lex Fridman",
                    album = "Lex Fridman Podcasts",
                    category = "Podcasts",
                    duration = 5400,
                    imageUrl = "podcast_lex",
                    isPodcast = true,
                    lyrics = """[00:01] Welcome. This is the Lex Fridman Podcast.
[00:06] Today I am speaking with Sam Altman, CEO of OpenAI, discussing Artificial General Intelligence (AGI)..."""
                ),
                // --- RADIO STATIONS ---
                SongEntity(
                    title = "BBC World Service Live",
                    artist = "BBC News",
                    album = "Global Broadcasting",
                    category = "Radio",
                    duration = 0, // Live
                    imageUrl = "radio_bbc",
                    isRadio = true,
                    lyrics = """[Live] Broadcast news, global events, culture, and science live from London."""
                ),
                SongEntity(
                    title = "Hot 97 NY Live",
                    artist = "WQHT 97.1 FM",
                    album = "Live Hip-Hop Hits",
                    category = "Radio",
                    duration = 0, // Live
                    imageUrl = "radio_hot97",
                    isRadio = true,
                    lyrics = """[Live] Delivering the hottest hip-hop, news, and street culture 24/7."""
                )
            )

            for (song in starterSongs) {
                dao.insertSong(song)
            }

            // Create a default playlist
            dao.insertPlaylist(PlaylistEntity(name = "My Summer Anthems"))
            dao.insertPlaylist(PlaylistEntity(name = "Chill Vibez"))
        }
    }
}
