package com.example.database

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface MusicDao {

    // --- SONGS ---
    @Query("SELECT * FROM songs ORDER BY id DESC")
    fun getAllSongs(): Flow<List<SongEntity>>

    @Query("SELECT * FROM songs WHERE isPodcast = 0 AND isRadio = 0 ORDER BY id DESC")
    fun getOnlyMusicSongs(): Flow<List<SongEntity>>

    @Query("SELECT * FROM songs WHERE isTrending = 1 ORDER BY id DESC")
    fun getTrendingSongs(): Flow<List<SongEntity>>

    @Query("SELECT * FROM songs WHERE isNewRelease = 1 ORDER BY id DESC")
    fun getNewReleases(): Flow<List<SongEntity>>

    @Query("SELECT * FROM songs WHERE category = :category ORDER BY id DESC")
    fun getSongsByCategory(category: String): Flow<List<SongEntity>>

    @Query("SELECT * FROM songs WHERE isPodcast = 1 ORDER BY id DESC")
    fun getPodcasts(): Flow<List<SongEntity>>

    @Query("SELECT * FROM songs WHERE isRadio = 1 ORDER BY id DESC")
    fun getRadioStations(): Flow<List<SongEntity>>

    @Query("SELECT * FROM songs WHERE id = :songId")
    suspend fun getSongById(songId: Int): SongEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSong(song: SongEntity): Long

    @Query("DELETE FROM songs WHERE id = :songId")
    suspend fun deleteSongById(songId: Int)

    // --- PLAYLISTS ---
    @Query("SELECT * FROM playlists ORDER BY createdAt DESC")
    fun getAllPlaylists(): Flow<List<PlaylistEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPlaylist(playlist: PlaylistEntity): Long

    @Query("DELETE FROM playlists WHERE id = :playlistId")
    suspend fun deletePlaylistById(playlistId: Int)

    @Query("SELECT * FROM playlists WHERE id = :playlistId")
    suspend fun getPlaylistById(playlistId: Int): PlaylistEntity?

    // --- PLAYLIST SONGS CROSSREF ---
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPlaylistSong(playlistSong: PlaylistSongEntity)

    @Query("DELETE FROM playlist_songs WHERE playlistId = :playlistId AND songId = :songId")
    suspend fun deletePlaylistSong(playlistId: Int, songId: Int)

    @Query("DELETE FROM playlist_songs WHERE playlistId = :playlistId")
    suspend fun deletePlaylistSongsByPlaylistId(playlistId: Int)

    @Query("""
        SELECT s.* FROM songs s 
        INNER JOIN playlist_songs ps ON s.id = ps.songId 
        WHERE ps.playlistId = :playlistId
    """)
    fun getSongsInPlaylist(playlistId: Int): Flow<List<SongEntity>>

    // --- FAVORITES ---
    @Query("""
        SELECT s.* FROM songs s 
        INNER JOIN favorites f ON s.id = f.songId 
        ORDER BY f.likedAt DESC
    """)
    fun getFavoriteSongs(): Flow<List<SongEntity>>

    @Query("SELECT EXISTS(SELECT 1 FROM favorites WHERE songId = :songId)")
    fun isSongFavorite(songId: Int): Flow<Boolean>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFavorite(favorite: FavoriteEntity)

    @Query("DELETE FROM favorites WHERE songId = :songId")
    suspend fun deleteFavorite(songId: Int)

    // --- HISTORY ---
    @Query("""
        SELECT s.* FROM songs s 
        INNER JOIN history h ON s.id = h.songId 
        ORDER BY h.playedAt DESC
    """)
    fun getRecentlyPlayed(): Flow<List<SongEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHistory(history: HistoryEntity)

    @Query("DELETE FROM history WHERE songId = :songId")
    suspend fun deleteHistoryBySongId(songId: Int)

    @Query("DELETE FROM history")
    suspend fun clearHistory()

    // --- DOWNLOADS ---
    @Query("""
        SELECT s.* FROM songs s 
        INNER JOIN downloads d ON s.id = d.songId 
        ORDER BY d.downloadedAt DESC
    """)
    fun getDownloadedSongs(): Flow<List<SongEntity>>

    @Query("SELECT EXISTS(SELECT 1 FROM downloads WHERE songId = :songId)")
    fun isSongDownloaded(songId: Int): Flow<Boolean>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDownload(download: DownloadEntity)

    @Query("DELETE FROM downloads WHERE songId = :songId")
    suspend fun deleteDownload(songId: Int)
}
