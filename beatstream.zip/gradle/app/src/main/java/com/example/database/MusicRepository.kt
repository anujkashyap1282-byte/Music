package com.example.database

import kotlinx.coroutines.flow.Flow

class MusicRepository(private val musicDao: MusicDao) {

    val allSongs: Flow<List<SongEntity>> = musicDao.getAllSongs()
    val musicOnlySongs: Flow<List<SongEntity>> = musicDao.getOnlyMusicSongs()
    val trendingSongs: Flow<List<SongEntity>> = musicDao.getTrendingSongs()
    val newReleases: Flow<List<SongEntity>> = musicDao.getNewReleases()
    val podcasts: Flow<List<SongEntity>> = musicDao.getPodcasts()
    val radioStations: Flow<List<SongEntity>> = musicDao.getRadioStations()
    val playlists: Flow<List<PlaylistEntity>> = musicDao.getAllPlaylists()
    val favoriteSongs: Flow<List<SongEntity>> = musicDao.getFavoriteSongs()
    val recentlyPlayed: Flow<List<SongEntity>> = musicDao.getRecentlyPlayed()
    val downloadedSongs: Flow<List<SongEntity>> = musicDao.getDownloadedSongs()

    suspend fun getSongById(songId: Int): SongEntity? = musicDao.getSongById(songId)

    suspend fun insertSong(song: SongEntity): Long = musicDao.insertSong(song)

    suspend fun deleteSongById(songId: Int) = musicDao.deleteSongById(songId)

    fun getSongsByCategory(category: String): Flow<List<SongEntity>> = musicDao.getSongsByCategory(category)

    suspend fun insertPlaylist(playlistName: String): Long {
        return musicDao.insertPlaylist(PlaylistEntity(name = playlistName))
    }

    suspend fun deletePlaylist(playlistId: Int) {
        musicDao.deletePlaylistSongsByPlaylistId(playlistId)
        musicDao.deletePlaylistById(playlistId)
    }

    suspend fun addSongToPlaylist(playlistId: Int, songId: Int) {
        musicDao.insertPlaylistSong(PlaylistSongEntity(playlistId, songId))
    }

    suspend fun removeSongFromPlaylist(playlistId: Int, songId: Int) {
        musicDao.deletePlaylistSong(playlistId, songId)
    }

    fun getSongsInPlaylist(playlistId: Int): Flow<List<SongEntity>> = musicDao.getSongsInPlaylist(playlistId)

    fun isSongFavorite(songId: Int): Flow<Boolean> = musicDao.isSongFavorite(songId)

    suspend fun toggleFavorite(songId: Int, isFav: Boolean) {
        if (isFav) {
            musicDao.deleteFavorite(songId)
        } else {
            musicDao.insertFavorite(FavoriteEntity(songId))
        }
    }

    suspend fun addToRecentlyPlayed(songId: Int) {
        musicDao.deleteHistoryBySongId(songId) // Remove existing to move to top
        musicDao.insertHistory(HistoryEntity(songId))
    }

    suspend fun clearHistory() = musicDao.clearHistory()

    fun isSongDownloaded(songId: Int): Flow<Boolean> = musicDao.isSongDownloaded(songId)

    suspend fun toggleDownload(songId: Int, isDownloaded: Boolean) {
        if (isDownloaded) {
            musicDao.deleteDownload(songId)
        } else {
            musicDao.insertDownload(DownloadEntity(songId))
        }
    }
}
