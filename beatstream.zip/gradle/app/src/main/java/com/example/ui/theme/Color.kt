package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Premium Neon Purple & Cyan Colorways
val CosmicPurple = Color(0xFFBB86FC)
val CosmicCyan = Color(0xFF03DAC6)
val CyberPink = Color(0xFFFF4081)

// Dark Slate Surfaces
val SpaceBlack = Color(0xFF0A0B10)
val DarkSlateSurface = Color(0xFF131520)
val DarkSlateCard = Color(0xFF1C1E2E)
val LightAccent = Color(0xFFE3E4F3)

// Light Theme Backups
val LightBackground = Color(0xFFF9FAFF)
val LightSurface = Color(0xFFFFFFFF)
val LightCard = Color(0xFFF0F2FF)

// Original legacy values kept for compatibility
val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)
val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)
